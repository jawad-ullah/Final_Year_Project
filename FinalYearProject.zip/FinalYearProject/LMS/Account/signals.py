# from Account.models import User,Admin_Profile
# from Teacher.models import Teacher
# from Student.models import Student
# from django.contrib.auth.models import Group
# from django.db.models.signals import post_save,pre_save
# from django.dispatch import receiver

# @receiver(post_save,sender=User)
# def create_profile(sender,instance,created,**kwargs):
#     print(sender)
#     print(instance)
#     print(created)
#     if created:
#         if instance.is_Teacher:
#             Teacher.objects.create(user=instance)
#         elif instance.is_Student and instance.email !="":
#             Student.objects.create(user=instance)
#         elif instance.is_Admin:
#             Admin_Profile.objects.create(user=instance)