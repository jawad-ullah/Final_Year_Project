
const department=document.querySelector('#id_Department');
console.log(department)
$.ajax({
    type:'GET',
    url:'/Account/Dept/',
    success:(response)=>{
       console.log(response.dept)
       Msg=response.dept;
       Msg.map(item=>{
           const option=document.createElement('option')
           option.textContent=item.Department_name
           option.setAttribute('value',item.id)
           department.appendChild(option)
       })
    },
   error:(error)=>{
       console.log(error)
   }

})
// First name validations
var Fname=document.getElementById('id_first_name');
var putfname=document.getElementById('putfname')
Fname.addEventListener('change',e=>{
        fname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Fname/${fname}/`,
            success:(response)=>{
                Msg=response.msg;
                putfname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})
  
// Last name Validation

var Lname=document.getElementById('id_last_name');
var putlname=document.getElementById('Putlname');
Lname.addEventListener('change',e=>{
        lname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Lname/${lname}/`,
            success:(response)=>{
                Msg=response.msg;
                putlname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})


// Father Name Validation

var Faname=document.getElementById('id_Father_Name');
var Putfaname=document.getElementById('Putfaname');
Faname.addEventListener('change',e=>{
        faname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Faname/${faname}/`,
            success:(response)=>{
                Msg=response.msg;
                Putfaname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})

// Email validation

var Email_field=document.getElementById('id_email');
console.log(Email_field)

var Putem=document.getElementById('Email');
Email_field.addEventListener('change',e=>{
        em=e.target.value;
        console.log(em)
        $.ajax({
            type:'GET',
            url:`/Admin/Em/${em}/`,
            success:(response)=>{
                Msg=response.msg;
                Putem.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})

var Cno=document.getElementById('id_contact_no');
var Putcno=document.getElementById('PutContact');
Cno.addEventListener('change',e=>{
        cno=e.target.value;
        console.log(cno)
        $.ajax({
            type:'GET',
            url:`/Admin/CNO/${cno}/`,
            success:(response)=>{
                Msg=response.msg;
                Putcno.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})
const psw1=document.getElementById('id_password1');
const Putpsw1=document.getElementById('password1');
psw1.addEventListener('change', e=>{
    console.log(e.target.value)
    const psw1=e.target.value
     $.ajax({
         type: 'GET',
         url: `/Account/pass1/${psw1}/`,
         success:function(response){
            const getPsw1=response.Psw1;
             console.log(getPsw1)
             Putpsw1.innerHTML=`
                ${getPsw1}
             `
         },
         error:function(error){
             console.log(error)
         }
     })
 })

const psw2=document.getElementById('id_password2');
const Putpsw2=document.getElementById('password2');
psw2.addEventListener('change', e=>{
    console.log(e.target.value)
   const psw2=e.target.value
     $.ajax({
         type: 'GET',
         url: `/Account/pass2/${psw2}/`,
         success:function(response){
            const getPsw2=response.Psw2;
             console.log(getPsw2)
             Putpsw2.innerHTML=`
                ${getPsw2}
             `
         },
         error:function(error){
             console.log(error)
         }
     })
 })
 //Login page email validation
