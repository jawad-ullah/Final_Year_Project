const dept=document.getElementById('Department').style.display='none';
const sem=document.getElementById('semester').style.display='none';
const teacher=document.getElementById('id_Role_1')
const student=document.getElementById('id_Role_2')
const admin=document.getElementById('id_Role_0')
const Sel=document.getElementsByClassName('sel')

admin.addEventListener('change',e=>{
    console.log(e.target.value)
    for (let i = 0; i < Sel.length; i++) {
        console.log(i)
        Sel[i].style.display='none';
        
    }
})
teacher.addEventListener('click',e=>{
    console.log(e.target.value);
    if(e.target.value=='Teacher')
    {
        for (let i = 0; i < Sel.length-1; i++) {
            console.log(i)
            Sel[i].style.display='block';
            
        }
    }
})

student.addEventListener('click',e=>{
    console.log(e.target.value)
   if(e.target.value=='Student')
   {
    for (let i = 0; i < Sel.length; i++) {
        console.log(i)
        Sel[i].style.display='block';
        
    }
   }
});
// First name validations
const fname=document.getElementById('id_first_name')
const putFname=document.getElementById('Putfname')
fname.addEventListener('change',e=>{
    console.log(e.target.value);
    Fname=e.target.value;
    console.log(typeof Fname);
    $.ajax({
        type:'GET',
        url:`/Account/FnameCheck/${Fname}/`,
        success:function(response){
            console.log(response.fname);
            Fname=response.fname;
            putFname.innerHTML=`
           ${Fname}
            `

        },
        error:(error)=>{
            console.log(error)
        }
    })
})

// Last name Validations
const lname=document.getElementById('id_last_name')
const putLname=document.getElementById('Putlname')
lname.addEventListener('change',e=>{
    console.log(e.target.value);
    Lname=e.target.value;
    console.log(typeof Lname);
    $.ajax({
        type:'GET',
        url:`/Account/LnameCheck/${Lname}/`,
        success:function(response){
            console.log(response.fname);
            Lname=response.fname;
            putLname.innerHTML=`
           ${Lname}
            `

        },
        error:(error)=>{
            console.log(error)
        }
    })
})

//Father name Validation
const faname=document.getElementById('id_Father_Name')
console.log(faname);
const putFaname=document.getElementById('Putfaname')
faname.addEventListener('change',e=>{
    console.log(e.target.value);
    Faname=e.target.value;
    console.log(typeof Faname);
    $.ajax({
        type:'GET',
        url:`/Account/FatherNameCheck/${Faname}/`,
        success:function(response){
            console.log(response.fname);
            Faname=response.fname;
            putFaname.innerHTML=`
           ${Faname}
            `

        },
        error:(error)=>{
            console.log(error)
        }
    })
})

const Cno=document.getElementById('no')
console.log(Cno);
const putContact_no=document.getElementById('PutContact')
Cno.addEventListener('change',e=>{
    console.log(e.target.value);
    cno=e.target.value;
    console.log(typeof cno);
    $.ajax({
        type:'GET',
        url:`/Account/ContactCheck/${cno}/`,
        success:function(response){
            console.log(response.Cnumber);
            Faname=response.Cnumber;
            putContact_no.innerHTML=`
           ${Faname}
            `

        },
        error:(error)=>{
            console.log(error)
        }
    })
})


//Email validations
const em=document.getElementById('id_email');
const PutEmail=document.getElementById('Email');
console.log(em)
em.addEventListener('change', e=>{
    console.log(e.target.value)
    mil=e.target.value
     $.ajax({
         type: 'GET',
         url: `/Account/EmailCheck/${mil}/`,
         success:function(data){
            const getEmail=data.Error;
             console.log(getEmail)
             PutEmail.innerHTML=`
                ${getEmail}
             `
         },
         error:function(data){
             console.log(data.Error)
         }
     })
 })

 //Login page email validation
