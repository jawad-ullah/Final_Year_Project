from django.urls import path
from . import views
urlpatterns = [
    path('Register/',views.Register,name='register'),
    path('login/',views.Login,name='login'),
    path('Forgot Password/',views.Reset,name='Change_password'),
    path('logout/',views.Logout,name='logout'),

    
    #JSON Work
    path('Dept/',views.get_dept,name='dept-json'),
    path('FnameCheck/<str:fname>/',views.Fname_checking,name='fname-json'),
    path('LnameCheck/<str:lname>/',views.Lname_checking,name='lname-json'),
    path('FatherNameCheck/<str:Faname>/',views.Father_Name_checking,name='faname-json'),
    path('ContactCheck/<str:cno>/',views.Contact_No_Checking,name='cno-json'),
    path('EmailCheck/<str:mil>/',views.Email_Checking,name='em-json'),
    path('pass1/<str:p1>/',views.Password1_checking,name='psw1-json'),
    path('pass2/<str:p2>/',views.Password2_checking,name='psw2-json'),
    
 ]
