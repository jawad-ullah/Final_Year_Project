from django.contrib.auth.password_validation import password_changed
from django.shortcuts import render,redirect
from Account.forms import LoginForm, SignUpForm
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import authenticate, login, logout, tokens, update_session_auth_hash
from django.contrib import messages
from core.models import *
from django.http import JsonResponse

# Create your views here.

#Register a User 
def Register(request):
    if not request.user.is_authenticated:
        form=SignUpForm(request.POST,request.FILES or None)
        error=None
        if request.method=="POST":
            if form.is_valid():
                em=form.cleaned_data.get('email')
                is_exist=User.objects.filter(email=em).exists()
                if is_exist:
                    raise ValidationError('Email is Already exists Try another!')
                else:
                    form.save()
                    messages.success(request,"User Successfully Registererd")
                    return redirect('/Account/login/')
            else:
                error=form.errors
                print(error)
        dept=Department.objects.all()
        context={
            'form':form,
            'error':error,
            'dept':dept,
        }
        return render(request,'Register.html',context)
    else:
        if request.user.is_Admin:
            return redirect('/Admin/Admin Dashboard/')
        elif redirect.user.is_Student:
            return redirect('/Student/Student_Dashboard/')
        else:
            return redirect('/Teacher/Teacher_Dashboard/')


# Login View

def Login(request):
    if not request.user.is_authenticated:
        error=None
        if request.method=='POST':
            fm=LoginForm(request.POST)
            if fm.is_valid():
                em=fm.cleaned_data['email']
                pas=fm.cleaned_data['password']
                user=authenticate(email=em,password=pas)
                if user is not None and user.Role=='Admin':
                    login(request,user)                   
                    return redirect('/Admin/Admin Dashboard/')
                elif user is not None and user.Role=='Teacher' and user.is_Approved:
                    login(request,user)
                    return redirect('/Teacher/Teacher_Dashboard/')
                elif user is not None and user.Role=='Student' and user.is_Approved:
                    login(request,user)
                    return redirect('/Student/Student_Dashboard/')
                else:
                    messages.warning(request,'Invalid Credientials try again!')
            else:
                error=fm.errors
                print(error)
        fm=LoginForm()
        return render(request,'login.html',{'form':fm,'error':error})
    else:
        if request.user.Role=='Admin':
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect('/Student/Student_Dashboard/')
        else:
            return redirect('/Teacher/Teacher_Dashboard/')

#Logged Out
def Logout(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request,"Successfully Logged Out")
        return redirect('/Account/login/')
    else:
        return redirect('/Account/login/')
#Change Password
def Reset(request):
    error=None
    fm=PasswordChangeForm(user=request.user)
    return render(request,'Resetpassword.html',{'form':fm,'error':error})


#JSON WORK and registration validations

#First name validations
def Fname_checking(request,*args, **kwargs):
    Fname=kwargs.get("fname")
    if Fname.isnumeric():
        error='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">First name only accept alphabets</strong>';
        return JsonResponse({
            'fname':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i> '
        return JsonResponse({
            'fname':error
        })

#last name validation
def Lname_checking(request,*args, **kwargs):
    Lname=kwargs.get("lname")
    if Lname.isnumeric():
        error='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">Last name only accept alphabets</strong>';
        return JsonResponse({
            'fname':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'fname':error
        })

#Father name Check

def Father_Name_checking(request,*args, **kwargs):
    Faname=kwargs.get("Faname")
    if Faname.isnumeric():
        error='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field only accept alphabets</strong>';
        return JsonResponse({
            'fname':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'fname':error
        })


#Email validations
def Email_Checking(request, *args, **kwargs):
    Em=kwargs.get('mil')
    print(Em)
    useremail=User.objects.filter(email=Em).exists()
    print(useremail)
    if useremail:
        error='<strong class="text-danger">* Email already exists! Choose Another</strong>';
        return JsonResponse(data={
            'Error':error
            })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse(data={
            'Error':error
      })
# Contact Validation
def Contact_No_Checking(request, *args, **kwargs):
    Co=kwargs.get('cno')
    print(type(Co))
    if not Co.isnumeric():
        error='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field only accept numbers</strong>';
        return JsonResponse({
            'Cnumber':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'Cnumber':error
        })

def Password1_checking(request, *args, **kwargs):
    Psw1=kwargs.get('p1')
    print(Psw1)
    if len(Psw1)<8:
        error='<i class="text-danger fas fa-times"></i><strong class="text-danger">length must be greater then 8 alphabets</strong>';
        return JsonResponse({
            'Psw1':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'Psw1':error
        })

def Password2_checking(request, *args, **kwargs):
    Psw2=kwargs.get('p2')
    print(Psw2)
    if len(Psw2)<8:
        error='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">length must be greater then 8 alphabets</strong>';
        return JsonResponse({
            'Psw2':error
        })
    else:
        error='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'Psw2':error
        })
def get_dept(request):
    dept=Department.objects.all().values()
    return JsonResponse({
        'dept':list(dept)
    })
