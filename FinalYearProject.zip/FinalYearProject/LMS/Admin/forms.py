from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.db.models import fields
from core.models import Course_Outline,Course,User,Department,User

class Registration(UserCreationForm):
    first_name=forms.CharField(max_length=50,help_text='first_name',required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'First name',
    }))
    last_name=forms.CharField(max_length=50,help_text='last_name',required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Last name',
    }))
    Father_Name=forms.CharField(max_length=50,help_text='last_name',required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Last name',
    }))
    email=forms.CharField(max_length=100,help_text='email',required=True,widget=forms.EmailInput(attrs={
        'class':'form-control',
        'type':'email',
        'placeholder':'Email',
    }))
    password1=forms.CharField(max_length=10,help_text='password',required=True,widget=forms.PasswordInput(attrs={
        'class':'form-control',
        'type':'password',
        'placeholder':'passoword',
    }))
    password2=forms.CharField(max_length=10,help_text='password',required=True,widget=forms.PasswordInput(attrs={
        'class':'form-control',
        'type':'password',
        'placeholder':'Confirm password',
    }))
    class Meta:
        model=User
        fields=[
            'first_name',
            'last_name',
            'Father_Name',
            'email',
            'Department',
            'Semister',
            'Address',
            'contact_no',
            'Role',
            'Profile_Img',
            'is_Approved',
            ]
        widgets={
            'Department':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Semister':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Address':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'contact_no':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'Role':forms.RadioSelect(),
            }
        labels={
            'is_Admin':'Admin',
            'is_Student':'Student',
            'is_Teacher':'Teacher',
            'is_Approved':'Approved',
            'password1':'Password',
            'password2':'Confirm Password',
            'Profile_Img':'Image',
        }
        
    def clean_first_name(self):
        fname = self.cleaned_data["first_name"]
        if not fname.isalpha():
            raise forms.ValidationError('This field contain only alphabets [a-z A-Z]')
        return fname

    def clean_last_name(self):
        lname = self.cleaned_data["last_name"]
        if not lname.isalpha():
            raise forms.ValidationError('This field contain only alphabets [a-z A-Z]')
        return lname

    def clean_Father_Name(self):
        faname = self.cleaned_data["Father_Name"]
        if not faname.isalpha():
            raise forms.ValidationError('This field contain only alphabets [a-z A-Z]')
        return faname
    def clean_contact_no(self):
        cno = self.cleaned_data["contact_no"]
        if not cno.isnumeric():
            raise forms.ValidationError('Contact number must contain only numbers')
        return cno
    def clean_password1(self):
        password1 = self.cleaned_data["password1"]
        if len(password1)<8:
            raise forms.ValidationError('Your password must contain at least 8 characters.')
        elif password1.isnumeric():
            raise forms.ValidationError("Your password Must be alphanumeric.")
        return password1
    
    def clean_password2(self):
        passowrd2 = self.cleaned_data["password2"]
        if passowrd2 != self.clean_password1():
            raise forms.ValidationError("The two password fields didn't match.")
        return passowrd2


class Course_Outline_ModelForm(forms.ModelForm):
    class Meta:
        model=Course_Outline
        fields='__all__'
        widgets={
            'File':forms.FileInput(attrs={'type':'file','class':'form-control'}),
            'Department':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Semister':forms.Select(attrs={'type':'select','class':'form-control'}),
            }
        labels={
            'File':'File',
        }

        def clean_File(self):
            File = self.cleaned_data.get('File')
            if File=="":
                raise forms.ValidationError("Field is Required")  
            else:      
                return File

        def clean_Department(self):
            Department = self.cleaned_data.get('Department')
            if Department=="":
                raise forms.ValidationError("Field is Required")  
            else:      
                return Department

class Edit_UserForm(forms.ModelForm):
    first_name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'First name',
    }))
    last_name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Last name',
    }))
    Father_Name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Father name',
    }))
    email=forms.CharField(max_length=100,required=True,widget=forms.EmailInput(attrs={
        'class':'form-control',
        'type':'email',
        'placeholder':'Email',
    }))
    class Meta:
        model=User
        fields=[
            'first_name',
            'last_name',
            'Father_Name',
            'email',
            'Department',
            'Semister',
            'Address',
            'contact_no',
            'Role',
            'is_Approved',
        ]
        widgets={
            'Department':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Semister':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Address':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'contact_no':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'Role':forms.RadioSelect(),
            }
        labels={
            'is_Admin':'Admin',
            'is_Student':'Student',
            'is_Teacher':'Teacher',
            'is_Approved':'Approved',

        }

class DeptModelForm(forms.ModelForm):
    class Meta:
        model=Department
        fields='__all__'
        widgets={
            'Department_name':forms.TextInput(attrs={
                'class':'form-control',
                'type':'text',
                'placeholder':'Department',
            })
        }

