    /*Data table */
    $(document).ready(function() {
        $('#DataTable').DataTable();
    });
    
  
    $('.admin_img').colorbox({
      'rel':'img',
      transition:'fadeIn',
      scalePhotos:true,
      width:'500px',
      height:'500px',
      maxHeight:'100%',
      maxWidth:'100%',
      top:'-10px',
  
    });
  $('.ui.dropdown').dropdown('show');
  
 // Course Outline JS
const Dept=document.getElementById('department')
console.log(Dept)
 $.ajax({
     type:'GET',
     url:'/Admin/Dept/',
     success:(response)=>{
        console.log(response.msg)
        Msg=response.msg;
        Msg.map(item=>{
            const option=document.createElement('option')
            option.textContent=item.Department_name
            option.setAttribute('value',item.id)
            Dept.appendChild(option)
        })
     },
    error:(error)=>{
        console.log(error)
    }
 })

 // Time table Js

 const timeTable=document.querySelector('#Department');

 $.ajax({
     type:'GET',
     url:'/Admin/Dept/',
     success:(response)=>{
        console.log(response.msg)
        Msg=response.msg;
        Msg.map(item=>{
            const option=document.createElement('option')
            option.textContent=item.Department_name
            option.setAttribute('value',item.id)
            timeTable.appendChild(option)
        })
     },
    error:(error)=>{
        console.log(error)
    }

 })
  
// Json Work for  Teacher Registration form
  // First name validation
var Fname=document.getElementById('id_first_name');
var putfname=document.getElementById('putfname')
Fname.addEventListener('change',e=>{
        fname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Fname/${fname}/`,
            success:(response)=>{
                Msg=response.msg;
                putfname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})
  
// Last name Validation

var Lname=document.getElementById('id_last_name');
var putlname=document.getElementById('Putlname');
Lname.addEventListener('change',e=>{
        lname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Lname/${lname}/`,
            success:(response)=>{
                Msg=response.msg;
                putlname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})


// Father Name Validation

var Faname=document.getElementById('id_Father_Name');
var Putfaname=document.getElementById('Putfaname');
Faname.addEventListener('change',e=>{
        faname=e.target.value;
        $.ajax({
            type:'GET',
            url:`/Admin/Faname/${faname}/`,
            success:(response)=>{
                Msg=response.msg;
                Putfaname.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})

// Email validation

var Email_field=document.getElementById('id_email');
console.log(Email_field)

var Putem=document.getElementById('Email');
Email_field.addEventListener('change',e=>{
        em=e.target.value;
        console.log(em)
        $.ajax({
            type:'GET',
            url:`/Admin/Em/${em}/`,
            success:(response)=>{
                Msg=response.msg;
                Putem.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})

var Cno=document.getElementById('id_contact_no');
var Putcno=document.getElementById('PutContact');
Cno.addEventListener('change',e=>{
        cno=e.target.value;
        console.log(cno)
        $.ajax({
            type:'GET',
            url:`/Admin/CNO/${cno}/`,
            success:(response)=>{
                Msg=response.msg;
                Putcno.innerHTML=`${Msg}`;

            },
            error:(error)=>{
                console.log(error)
            }
        })
})

// Department data using Ajax
console.log("Hi ")
const dept=document.querySelector('#id_Department')
console.log(dept)
$.ajax({
    type:'GET',
    url:'/Admin/Dept/',
    success:(response)=>{
        console.log(response.msg);
        Data=response.msg
        Data.map(item=>{
            const option=document.createElement('option')
            option.textContent=item.Department_name;
            option.setAttribute('value',item.id)
            option.setAttribute('class','item')
            dept.appendChild(option)
        })
    },
    error:(error)=>{
        console.log(error);
    }
})