from django.urls import path
from . import views

urlpatterns=[
    path('Admin Dashboard/',views.Admin,name='Admin Dashboard'),
    path('Departmental Admin/',views.DepartmentalAdmin,name="SuperAdmin"),
    path('Requested Users/',views.Req_Users,name='Requested Users'),
    path('Approved users/',views.Approved_Users,name='Approved Users'),
    path('User Edit/<int:id>/',views.User_Edit,name='User_Edit'),
    path('Approved users/<int:id>/',views.Edit_Approved_users,name="Approved"),
    path('Detail/<int:id>/',views.Detail,name='Detail'),

    path('Delete/<int:id>/',views.delete,name='Delete'),
    path('Course_Outline/',views.Course_outline,name='Course_outline'),
    path('Upload Course Outline/',views.Upload_Course_Outline,name='Upload_Course_Outline'),
    path('TimeTable/',views.Timetable,name='timeTable'),
    path('Upload_Time_table/',views.Upload_Time_table,name='Upload_Time_table'),
    path('All_Dept/',views.Departments,name='All_Dept'),
    path('Add Dept/',views.AddDept,name='AddDept'),
    path('Edit Dept/<int:id>/',views.Edit_Dept,name="EditDept"),
    path('Delete Dept/<int:id>/',views.DeleteDept,name='delDept'),
    path('delete/<int:id>/',views.Delete_course,name="delete_cou"),

    # Super Admin urls
    path('Registration/',views.registration,name='reg'),
    #Teacher Registration Validation using Ajax;
    path('Fname/<str:name>/',views.fname,name='fname-json'),
    path('Lname/<str:name>/',views.lname,name='lname-json'),
    path('Faname/<str:name>/',views.Faname,name='faname-json'),
    path('Em/<str:mail>/',views.e_mail,name='em-json'),
    path('CNO/<str:Cno>/',views.Cno,name='cno-json'),
    path('Dept/',views.department,name='dept-json'),

]