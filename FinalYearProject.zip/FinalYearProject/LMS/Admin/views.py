from django.shortcuts import render,redirect
from django.contrib import messages
from Account.forms import SignUpForm
from core.models import Course_Outline,TimeTable,Course,Department,Semister,User
from .forms import Edit_UserForm,Course_Outline_ModelForm,DeptModelForm
from Account.forms import SignUpForm
from Student.forms import TimeTableModelForm
from django.http import JsonResponse
# Create your views here.
def Admin(request):
    if request.user.is_authenticated:
        if request.user.Role=='Admin' and request.user.Department != None:
            teachers=User.objects.filter(Role='Teacher',Department=request.user.Department).count()
            students=User.objects.filter(Role='Student', Department=request.user.Department).count()
            dept=Department.objects.all().count()
            cou=Course.objects.filter(Department=request.user.Department).count()
            Requested_Users=User.objects.filter(is_Approved=False,Department=request.user.Department).count()
            Approved_Users=User.objects.filter(is_Approved=True,Department=request.user.Department).count()
            superAdmin=User.objects.all().filter(Role='Admin',Department=None).count()
            DAdmin=User.objects.all().filter(Role="Admin").count()
            DepartmentalAdmin=DAdmin-superAdmin
        elif request.user.Role=='Admin' and request.user.Department == None:
            teachers=User.objects.filter(Role='Teacher').count()
            students=User.objects.filter(Role='Student').count()
            dept=Department.objects.all().count()
            cou=Course.objects.all().count()
            Requested_Users=User.objects.filter(is_Approved=False,Role='Admin').count()
            Approved_Users=User.objects.filter(is_Approved=True,Department=request.user.Department).count()
            superAdmin=User.objects.all().filter(Role='Admin',Department=None).count()
            DAdmin=User.objects.all().filter(Role="Admin").count()
            DepartmentalAdmin=DAdmin-superAdmin;
        context={
            'title':'dashboard',
            'teachers':teachers,
            'students':students,
            'Requested_Users':Requested_Users,
            'Approved_Users':Approved_Users,
            'dept':dept,
            'cou':cou,
            'superAdmin':DepartmentalAdmin,
        }
        return render(request, 'Admin_Dashboard.html', context)

    else:
        return redirect('/Account/login/')

def DepartmentalAdmin(request):
    if request.user.is_authenticated:
        admin=User.objects.all().filter(Role='Admin')
        print(admin)
        context={
            'admin':admin
        }
        return render(request,'DepartmentalAdmin.html',context)
            
def Approved_Users(request):
    if request.user.is_authenticated:
        if request.user.Role=="Admin" and request.user.Department != None:
            app_users=User.objects.all().filter(is_Approved=True ,Department=request.user.Department) 
            context={
                'title':'Approved Users',
                'users':app_users,
            }
            return render(request,'Approved_user.html',context)
        elif request.user.Role=="Admin" and request.user.Department == None:
            app_users=User.objects.all().filter(is_Approved=True,Role="Admin") 
            context={
                'title':'Approved Users',
                'users':app_users,
            }
            return render(request,'Approved_user.html',context)
    else:
        return redirect('/Admin/login/')    
def Req_Users(request):
    if request.user.is_authenticated:
        if request.user.Role=="Admin" and request.user.Department != None:
            req_users=User.objects.all().filter(is_Approved=False ,Department=request.user.Department) 
            context={
                'title':'Requested Users',
                'users':req_users,
            }
            return render(request,'Approved_user.html',context)
        elif request.user.Role=="Admin" and request.user.Department == None:
            req_users=User.objects.all().filter(is_Approved=False,Role="Admin") 
            context={
                'title':'Requested Users',
                'users':req_users,
            }
            return render(request, 'Requested_Users.html', context)
    else:
        return redirect('/Account/login/')


def User_Edit(request,id):
    if request.user.is_authenticated and request.user.Role=='Admin':
        error=None
        user=User.objects.get(id=id)
        if request.method=="POST":
            U_form=Edit_UserForm(request.POST,instance=user)
            if U_form.is_valid():
                U_form.save()
                messages.success(request,f"{user.first_name} {user.last_name} is Successfully Updated")
                return redirect('/Admin/Admin Dashboard/')
            else:
                error=U_form.errors
        U_form=Edit_UserForm(instance=user)
        context={
            'title':'Edit Requested User',
            'form':U_form,
            'error':error
        }
        return render(request, 'User_Edit.html', context)
    else:
        return redirect('/Account/login/')

def Edit_Approved_users(request,id):
    if request.user.is_authenticated and request.user.Role=='Admin':
        error=None
        user=User.objects.get(id=id)
        if request.method=="POST":
            U_form=Edit_UserForm(request.POST,instance=user)
            if U_form.is_valid():
                exist=User.objects.filter(
                    Department=U_form.cleaned_data.get('Department'),
                    Role=U_form.cleaned_data.get('Role'),
                    email=U_form.cleaned_data.get('email'),
                    ).first()
                if exist:
                    messages.warning(request,f"Admin with this Department already taken")
                    return redirect('/Admin/Admin Dashboard/')
                U_form.save()
                messages.success(request,f"User is Updated Successfully")
                return redirect('/Admin/Admin Dashboard')
            else:
                error=U_form.errors
        U_form=Edit_UserForm(instance=user)
        context={
            'title':'Edit Approved User',
            'form':U_form,
            'error':error
        }
        return render(request, 'User_Edit.html', context)
    else:
        return redirect('/Account/login/')
    

def Departments(request):
    depts=Department.objects.all()
    context={'title':'Departments','dept':depts}
    return render(request,'Departments.html',context)

def AddDept(request):
    if request.user.is_authenticated:
        d_form=DeptModelForm(request.POST or None)
        if request.method=="POST":
            if d_form.is_valid():
                dept=d_form.cleaned_data.get('Department_name')
                is_Exist=Department.objects.filter(Department_name=dept).exists()
                if is_Exist:
                    messages.warning(request,'Department Already exist Try Another!')
                else:
                    d_form.save()
                    messages.success(request,f" Department is successfully Added")
                    return redirect('/Admin/All_Dept/')
        context={
            'dform':d_form
        }
        return render(request, 'Add_Dept.html',context)
        
    else:
        return redirect('/Account/login/')

def Edit_Dept(request,id):
    if request.user.is_authenticated:
        dept=Department.objects.get(pk=id)
        dform=DeptModelForm(request.POST,instance=dept)
        if request.method=="POST":
            if dform.is_valid():
                dform.save()
                messages.success(request,"Successfully Updated")
                return redirect('/Admin/All_Dept/')
        dform=DeptModelForm(instance=dept)
        context={
            'form':dform,
        }
        return render(request, 'Edit_Dept.html', context)
        
    else:
        return redirect('/Account/login/')

def DeleteDept(request,id):
    if request.user.is_authenticated:
        dept=Department.objects.get(pk=id)
        dept.delete()
        messages.success(request,"Successfully Deleted")
        return redirect('/Admin/All_Dept/')
        
    else:
        return redirect('/Account/login/')

def All_Courses(request):
    cour=Course.objects.all()
    context={'title':'All Courses','cour':cour}
    return render(request,'All_Courses.html',context)

def Detail(request,id):
    if request.user.is_authenticated and request.user.Role=='Admin':
        user=User.objects.get(pk=id)
        context={
            'title':'Teacher Detail',
            'form':user,
        }
        return render(request, 'Detail.html', context)
    else:
        return redirect('/Account/login/')

def delete(request,id):
    if request.user.is_authenticated and request.user.Role=="Admin":
        user=User.objects.get(pk=id)
        user.delete()
        messages.success(request,'Successfully Deleted')
        return redirect("/Admin/Admin Dashboard/")            
    else:
        return redirect('/Account/login/')

#Upload_Course_outline
def Course_outline(request):
    if request.user.is_authenticated and request.user.Role=='Admin':
        outline=Course_Outline.objects.all()
        context={'title':'Course Outline','Outline':outline}
        return render(request,'Course_Outline.html',context)
    else:
        return redirect('/Account/login/')

def Upload_Course_Outline(request):
    error=None
    if request.user.is_authenticated and request.user.Role=="Admin":
        fm=Course_Outline_ModelForm(request.POST,request.FILES or None)
        if request.method=='POST':
            if fm.is_valid():
                fm.save()
                messages.success(request,'Course Outline Successfully added')
                return redirect('/Admin/Course_Outline/')
            else:
                error=fm.errors
        context={'title':'Upload Course Outlne','fm':fm,"error":error}
        return render(request, 'Upload_Course_Outline.html',context)
        
    else:
        return render('/Account/login/')

#Time table
def Timetable(request):
    if request.user.is_authenticated and request.user.Role=='Admin':                 
        timetable=TimeTable.objects.all()
        context={
            'title':'Timetables',
            'timetable':timetable,
        }
        return render(request, 'TimeTable.html',context)
        
    else:
        return redirect('/Account/login/')

#Upload Time Table
def Upload_Time_table(request):
    error=None
    if request.user.is_authenticated and request.user.Role=='Admin':                 
        fm=TimeTableModelForm(request.POST,request.FILES or None)
        if fm.is_valid():
            fm.save()
            messages.success(request,"TimeTable Successfully Added")
            return redirect('/Admin/TimeTable/')
        else:
            error=fm.errors
        context={
            'title':'Upload TimeTable',
            'fm':fm,
            'error':error,
        }
        return render(request, 'Upload_Time_Table.html',context)
        
    else:
        return redirect('/Account/login/')

def Delete_course(request,id):
    if request.user.is_authenticated and request.user.Role=="Admin":
        cou=Course.objects.get(pk=id)
        cou=cou.delete()
        messages.success(request,f"{cou.Subject_name} is Successflly deleted")
        return redirect('/Admin/delete/')
    else:
        return redirect('/Account/login/')


# Super Admin Code

def registration(request):
    if request.user.is_authenticated and request.user.Role == 'Admin':
        error=None
        if request.method == 'POST':
            fm=SignUpForm(request.POST,request.FILES)
            if fm.is_valid():
                fm.save()
                messages.success(request,f"User is Successfully Registered")
                return redirect('/Admin/Admin Dashboard/')
            else:
                error=fm.errors;
        fm=SignUpForm()
        context={
            'form':fm,
            'error':error
        }
        return render(request,'Registration.html',context)
    else:
        return redirect('/Account/login/')

# JSON Work for Teacher Registration form

def fname(request,*args, **kwargs):
    Fname=kwargs.get('name')
    if Fname.isnumeric():
        msg='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field only accept alphabets</strong>';
        return JsonResponse({
            'msg':msg
        })
    else:
        msg='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'msg':msg
        })

def lname(request,*args, **kwargs):
    Lname=kwargs.get('name')
    if Lname.isnumeric():
        msg='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field only accept alphabets</strong>';
        return JsonResponse({
            'msg':msg
        })
    else:
        msg='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'msg':msg
        })

def Faname(request,*args, **kwargs):
    Lname=kwargs.get('name')
    if Lname == None:
        msg='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field is required</strong>';
        return JsonResponse({
            'msg':msg
        })
    else:
        msg='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'msg':msg
        })

def e_mail(request,*args, **kwargs):
    Em=kwargs.get('mail')
    useremail=User.objects.filter(email=Em).exists()
    if useremail:
        msg='<strong class="text-danger">* Email already exists! Choose Another</strong>';
        return JsonResponse(data={
            'msg':msg
            })
    else:
        msg='<i class=" text-success fas fa-check"></i>'
        return JsonResponse(data={
            'msg':msg
      })

def Cno(request,*args, **kwargs):
    cno=kwargs.get('Cno')
    if cno.isnumeric():
        msg='<i class=" text-success fas fa-check"></i>'
        return JsonResponse({
            'msg':msg
        })
    else:
        msg='<i class=" text-danger fas fa-times"></i> <strong class="text-danger">This field only accept intergers [0-9]</strong>';
        return JsonResponse({
            'msg':msg
        })

def department(request):
    msg=Department.objects.all().filter(Department_name=request.user.Department).values()
    return JsonResponse({
        'msg':list(msg)
    })
