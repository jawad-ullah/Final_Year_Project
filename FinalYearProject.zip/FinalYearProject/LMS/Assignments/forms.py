from django import forms
from core.models import Assignment,Assignment_Solution


class AssignmentModelForm(forms.ModelForm):
    class Meta:
        model=Assignment
        fields='__all__'
        widgets={
            'Assignemt_no':forms.TextInput(attrs={'type':'text','class':'form-control'}),
            'Subject':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Questions':forms.Textarea(attrs={'type':'select','col':2,'row':5,'class':'form-control'}),
            'deadline':forms.DateInput(attrs={'type':'Date','class':'form-control'})
            
            }
        # labels={
        #     'Assignment_no ':'Assignment No',
        #     'Assignment_Question':'Question',
        # }


class Assignment_SubmissionModelForm(forms.ModelForm):
    class Meta:
        model=Assignment_Solution
        fields='__all__'
        widgets={
            'assignment':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Answer':forms.FileInput(attrs={'type':'file','class':'form-control'}),
            'Status':forms.RadioSelect(),
            }
            