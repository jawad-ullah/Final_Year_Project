console.log('Hi')
const dept=document.getElementById('id_Department')
const sem=document.getElementById('id_Semister')
const std=document.getElementById('id_Student')

$.ajax({
    type:'GET',
    url:'/Assignment/dept-json/',
    success:function(response){
       const Data=response.dept;
        Data.map(item=>{
            const options=document.createElement('option')
            options.textContent=item.Department_name
            options.setAttribute('class','form-control')
            options.setAttribute('value',item.id)
            dept.appendChild(options)
        });
    },
    error:function(error)
    {
        console.log(error)
    }
})

$.ajax({
    type:'GET',
    url:`/Assignment/sem-json/`,
    success:function(response){
        Data=response.sem
        Data.map(item=>{
            const options=document.createElement('option')
            options.textContent=item.Semister_name
            options.setAttribute('class','form-control')
            options.setAttribute('value',item.id)
            sem.appendChild(options)
        })
    },
    error:function(error){console.log(error)}
})
$.ajax({
    type:'GET',
    url:`/Assignment/std-json/`,
    success:function(response){
        Data=response.std
        Data.map(item=>{
            const options=document.createElement('option')
            options.textContent=item.first_name +' '+ item.last_name
            options.setAttribute('class','form-control')
            options.setAttribute('value',item.id)
            std.appendChild(options)
        })
    },
    error:function(error){console.log(error)}
})

/**Add Assignment Subject */

const subj=document.getElementById('id_Subject')

$.ajax({
    type:'GET',
    url:'/Assignment/sub-json/',
    success:function(response){
        Data=response.subj
        Data.map(sub=>{
            const option=document.createElement('option')
            option.textContent=sub.Subject_name
            option.setAttribute('class','item')
            option.setAttribute('value',sub.id)
            subj.appendChild(option)
        })
    },
    error:function(error){console.log(error)}
})

