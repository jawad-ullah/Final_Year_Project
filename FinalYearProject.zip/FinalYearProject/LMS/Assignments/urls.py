from django.urls import path
from . import views

urlpatterns=[
    path('Assignment/',views.Assignments,name='assign'),
    path('Add Assignment/',views.AddAssignment,name='AddAssignment'),
    path('Edit_Assignment/<int:id>/',views.Edit_Assignment,name='edit_assignment'),
    path('Delete Assignment/<int:id>/',views.Delete_Assignment, name='delete_Assignment'),
    path("Assignmets/<int:id>/",views.CourseBaseAssignment,name='CourseBaseAssign'),
    path('Teacher Assignment/<int:id>/',views.TeacherAssignment,name='TeacherAssign'),
    path('Students/<int:id>/',views.ViewSubmittedAssignment,name="ViewSubmittedStudents"),
      #Student Assignemt URL Work
    path('Courses/',views.AssignmentCorses, name='AssCou'),
    path('Student Assignment/<int:id>/',views.Student_Assignment,name='stdAss'),
    path("Submit Assignment/<int:id>/",views.SubmitAssignment,name="SubmitAssignment"),

    #Submitted Assignment
    path('Submitted Assignment/<int:id>/',views.SubmittedAssignment,name='Submitted_Assignment'),
    #path('abc/<int:id>/',views.subAss,name='Sub'),
    #JSON Work
    path('dept-json/',views.dept_json_view,name='dept-json'),
    path('sem-json/',views.sem_json_view,name='sem-json'),
    path('std-json/',views.std_json_view,name='std-json'),
    path('sub-json/',views.Sub_json_view, name='sub-json'),
]