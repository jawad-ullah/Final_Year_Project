from django.shortcuts import render,redirect
from core.models import *
from .forms import AssignmentModelForm,Assignment_SubmissionModelForm
from django.contrib import messages
from django.http import JsonResponse
from datetime import date, datetime
# Create your views here.
# Assignments
def Assignments(request):
    if request.user.is_authenticated:
        cou=[]
        assign=[]
        SelctCourses=Course.objects.filter(Teacher__email=request.user.email)
        for c in SelctCourses:
            cou.append(c)
        for a in cou:
            assig=Assignment.objects.filter(Subject__Subject_name=a)
            assign.append(assig)
           
        mylist=zip(cou,assign)
        today=date.today()
        context={
            'title':'Assignments',
            'mylist':mylist,
            'today':today,
            }
        return render(request,'Teacher_Assignment.html',context)
    else:
        return redirect('/Account/login/')

#Add Assignment
def AddAssignment(request):
    error=None
    if request.method=='POST':
        fm=AssignmentModelForm(request.POST,request.FILES)
        if fm.is_valid():
            ass=fm.cleaned_data.get('Assignemt_no')
            print(ass)
            sub=fm.cleaned_data.get('Subject')
            print(sub)
            is_Exist=Assignment.objects.filter(Subject_id=sub,Assignemt_no=ass).exists()
            print(is_Exist)
            if is_Exist:
                messages.warning(request,'Assignment Already exist')
            else:
                fm.save()
                messages.success(request,'Assignment Is Added Successfully')
                return redirect('/Assignment/Assignment/')
        else:
            error=fm.errors
    fm=AssignmentModelForm()
    context={
        'title': 'Add Assignment',
        'form':fm,
        'error':error
    }
    return render(request,'New_Assignment.html',context)

#Edit Assignment
def Edit_Assignment(request,id):
    get_assign=Assignment.objects.get(pk=id)
    if request.method=='POST':
        fm=AssignmentModelForm(request.POST,request.FILES,instance=get_assign) 
        if fm.is_valid():
            messages.success(request,'Assignemt Edited Successfully')
            fm.save()
            return redirect('/Assignment/Assignment/')
    fm=AssignmentModelForm(instance=get_assign)
    context={'title':'Edit Assignment','form':fm}
    return render(request, 'Edit_Assignment.html',context)

#Delete Assignment
def Delete_Assignment(request,id):
    get_assign=Assignment.objects.get(pk=id)
    get_assign.delete()
    messages.success(request,'Assignemt Deleted Successfully')
    return redirect('/Assignment/Assignment/')


def CourseBaseAssignment(request,id):
    if request.user.is_authenticated:
        print(id)
        get_id=Assignment.objects.filter(Subject_id=id)
        context={
            'couAss':get_id
        }
        return render(request, 'CourseAssignemts.html',context)
    else:
        return redirect('/Account/login/')

# Teacher Assignemt Work
def TeacherAssignment(request,id):
    if request.user.is_authenticated and request.user.Role=='Teacher' or request.user.Role == 'Admin' and request.user.Department != None:
        Assig=Assignment.objects.filter(pk=id)
        Sub=Assignment_Solution.objects.filter(assignment_id=id , Status='submit').count()
        listView=Assignment_Solution.objects.filter(assignment_id=id)
        context={
            'assg':Assig,
            'sub':Sub,
            'listview':listView
        }
        return render(request,'TeacherAssignment.html',context)
    else:
        return redirect('/Account/login/')
# STudent Assignment Work
def AssignmentCorses(request):
    if request.user.is_authenticated:
        cou=[]
        ass=[]
        Cou=Course.objects.filter(Department=request.user.Department,Semister=request.user.Semister)
        for co in Cou:
            cou.append(co)
        for c in cou:
            Ass=Assignment.objects.filter(Subject=c)
            ass.append(Ass)
        mylists=zip(cou,ass)
        context={
            'cou':Cou,
            'mylist':mylists,
            'today':date.today()
        }
        return render(request, 'AssignmentCourses.html', context)
        
    else:
        return redirect('/Account/login/')
    
def Student_Assignment(request,id):
    if request.user.is_authenticated:
        stdAss=Assignment.objects.filter(Subject_id=id) 
        context={
            'studentAss':stdAss
        }
        return render(request, 'StudentAssignment.html', context)
        
    else:
        return redirect('/Account/login/')


def SubmitAssignment(request,id):
    if request.user.is_authenticated:
        error=None
        assi=Assignment.objects.get(pk=id)
        if request.method=='POST':
            aform = Assignment_SubmissionModelForm(request.POST,request.FILES)
            if aform.is_valid():
                sol=aform.save(commit=False)
                sol.Student=request.user
                sol.Subject=assi.Subject
                sol.assignment_no=assi.Assignemt_no
                ass=aform.cleaned_data.get('assignment')
                is_Exist=Assignment_Solution.objects.filter(Student=request.user,assignment=ass).exists()
                if is_Exist:
                    messages.warning(request,'You have already Submitted This Assignment')
                else:
                    sol.save()
                    messages.success(request,"Assignment is Successfully Submitted")
                    return redirect('/Assignment/Courses/')
            else:
                error=aform.errors
        form=Assignment_SubmissionModelForm(instance=assi)
        context={
            'form':form,
            'Sub':assi.Questions,
            'error':error
        }
        return render(request, 'SubmitAssignment.html',context)
        
    else:
        return redirect('/Account/login/')

# Submitted Assignment By Students
def SubmittedAssignment(request,id):
    if request.user.is_authenticated:
        get_ass=Assignment_Solution.objects.filter(Student=request.user)
        context={
            'ass':get_ass
        }
        return render(request,'Submitted_Assigment.html',context)
    else:
        return redirect('/Account/login/')


def ViewSubmittedAssignment(request,id):
    if request.user.is_authenticated and request.user.Role=='Teacher' or request.user.Role =='Admin' and request.user.Department !=None:
        Assig=Assignment.objects.filter(pk=id)
        Sub=Assignment_Solution.objects.filter(assignment_id=id , Status='submit').count()
        listView=Assignment_Solution.objects.filter(assignment_id=id)
        context={
            'sub':Sub,
            'listview':listView,
            'date':datetime.now()
        }
        return render(request,'ViewSubmittedStudents.html',context)
    else:
        return redirect('/Account/login/')
    

#JSON Work
def dept_json_view(request):
    if request.user.is_authenticated:
        dept=list(Department.objects.filter(Department_name=request.user.Department).values())
        return JsonResponse({
            'dept':dept,
        })
    else:
        return redirect('/Account/login/')
def sem_json_view(request):
    if request.user.is_authenticated:
        sem=list(Semister.objects.filter(Semister_name=request.user.Semister).values())
        return JsonResponse({
            'sem':sem,
        })
    else:
        return redirect('/Account/login/')

def std_json_view(request):
    if request.user.is_authenticated:
        std=list(User.objects.filter(Role='Student', username=request.user.username).values())
        return JsonResponse({
            'std':std,
        })
    else:
        return redirect('/Account/login/')

def Sub_json_view(request):
    if request.user.is_authenticated:
        subjects=list(Course.objects.filter(Teacher=request.user).values())
        return JsonResponse({
            'subj':subjects
        })
    else:
        return redirect('/Account/login/')
