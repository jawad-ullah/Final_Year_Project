from django import forms
from core.models import Course

class Course_ModelForm(forms.ModelForm):
    class Meta:
        model=Course
        fields='__all__'
        widgets={
            'Subject_name':forms.TextInput(attrs={'type':'text','class':'form-control','placeholder':'Enter Subject Name [eg:ICT]'}),
            'credits':forms.TextInput(attrs={'type':'number','class':'form-control','placeholder':'Enter Credit hours [eg:1,2,3,4]'}),
            'catagory':forms.TextInput(attrs={'class':'form-control Cat','type':'text','placeholder':'Enter catagory [eg:English]'}),
            'Department':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Semister':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Teacher':forms.Select(attrs={'type':'select','class':'form-control'}),
            }
        labels={
            'Subject':'Subject_name',
            'Credit Hour':'credits',
            'Catagory':'catagory',
        }

class Course_TeacherChange_ModelForm(forms.ModelForm):
    class Meta:
        model=Course
        fields='__all__'
        widgets={
            'Subject_name':forms.TextInput(attrs={'type':'text','class':'form-control','readonly':True}),
            'credits':forms.TextInput(attrs={'type':'number','class':'form-control','readonly':True}),
            'catagory':forms.TextInput(attrs={'class':'form-control','type':'text','placeholder':'Enter catagory [eg:English]','readonly':True}),
            'Department':forms.Select(attrs={'type':'select','class':'form-control','readonly':True}),
            'Semister':forms.Select(attrs={'type':'select','class':'form-control','readonly':True}),
            'Teacher':forms.Select(attrs={'type':'select','class':'form-control'}),
            }
        labels={
            'Subject':'Subject_name',
            'Credit Hour':'credits',
        }
        
       