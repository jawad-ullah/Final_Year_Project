$(document).ready(function() {
    $('#DataTable').DataTable();
});
//catagory based teacher retrieving
var catagory=document.querySelector('#id_catagory');
var teacher=document.querySelector('#id_Teacher');

// department retrieving
var department=document.querySelector('#id_department');

catagory.addEventListener('change',e=>{
    cata=e.target.value;
    teacher.innerHTML=''
    var opt=document.createElement('option')
    opt.textContent='---------';
    opt.setAttribute('value','none');
    teacher.appendChild(opt)
    $.ajax({
        type:'GET',
        url:`/Courses/Tea/${cata}/`,
        success:(response)=>
        {
            console.log(response.tea)
            teachers=response.tea;
            teachers.map(tea=>{
                var option=document.createElement('option')
                option.textContent=tea.first_name+' '+ tea.last_name;
                option.setAttribute('value',tea.id);
                option.setAttribute('class','item')
                teacher.appendChild(option)
            })
        },
        error:(error)=>
        {
            console.log(error)
        }
    })
})


// Course Assign form deoartment
$.ajax({
    type:'GET',
    url:'/Courses/Departments/',
    success:(response)=>{
        var Dept=response.dept;
        Dept.map(d=>{
            var option=document.createElement('option')
            option.textContent=d.Department_name;
            option.setAttribute('value',d.id)
            option.setAttribute('class','item')
            department.appendChild(option)
        })

    },
    error:(error)=>{
        console.log(error)
    }
})


// Assign Course To a Teacher
var getTeacherField=document.querySelector('#id_teacher')
var val=document.getElementById('id_catagory').value;

// $.ajax({
//     type:'GET',
//     url:`/Courses/assign_teacher/${val}/`,
//     success:(response)=>{
//         var Data=response.Tea
//         Data.map(t=>{
//             var opt=document.createElement('option');
//             opt.textContent=t.first_name+' '+ t.last_name;
//             opt.setAttribute('value',t.teacher);
//             getTeacherField.appendChild(opt)
//         })
//     },
//     error:(error)=>{
//         console.log(error)
//     }
// })


// Edit Course form Js
var Teachers=document.querySelector('.tea');
var Cat=document.querySelector('.Cat').value;
console.log(Cat)
$.ajax({
    type:'GET',
    url:`/Courses/edit_cou/${Cat}/`,
    success:(response)=>{
        var Tea=response.tea;
        Tea.map(t=>{
            var options=document.createElement('option')
            options.textContent=t.first_name+' '+t.last_name;
            options.setAttribute('value',t.id);
            Teachers.appendChild(options)
        })
    },
    error:(error)=>{
        console.log(error)
    }
})