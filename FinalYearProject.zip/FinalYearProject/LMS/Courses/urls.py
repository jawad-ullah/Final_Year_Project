from django.urls import path
from . import views
urlpatterns=[
    path('All Courses/',views.All_Courses, name='all_courses'),
    path("Upload Course/",views.Upload_Course,name='Upload_Course'),
    path("Assign Teacher/<int:id>/",views.Assign_Teacher_To_Course, name='Assign_teacher'),
    path('My Courses/',views.My_Courses,name='my_courses'),
    path('Edit Course/<int:id>/',views.Edit_Course,name='editCourse'),
    path('Delete Course/<int:id>/',views.delete_Course,name='delCourse'),

    # Json Work for Department,Teacher, in Course App

    # Departments
    path('Departments/',views.dept,name='dept-json'),

    # Teachers
    path('Tea/<str:catagory>/',views.tea,name='tea-json'),

    #Assign Teacher to course
    #path("assign_teacher/<str:cat>/",views.Assign_tea,name="ass-tea-json"),

    #Edit Course form
    path("edit_cou/<str:cat>/",views.Edit_cou, name="cou-json"),
]
