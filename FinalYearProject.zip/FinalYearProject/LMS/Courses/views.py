from django.shortcuts import render,redirect
from core.models import Course,Department,User
from .forms import Course_ModelForm,Course_TeacherChange_ModelForm
from django.contrib import messages
from django.http import JsonResponse
# Create your views here.
def All_Courses(request):
    if request.user.is_authenticated:
        if request.user.Role =='Admin' and request.user.Department != None:
            course=Course.objects.all().filter(Department=request.user.Department)
        elif request.user.Role=='Admin' and request.user.Department==None:
            course=Course.objects.all()
        elif request.user.Role=='Teacher':
            course=Course.objects.filter(Department= request.user.Department)
        elif request.user.Role=='Student':
            course=Course.objects.filter(Department= request.user.Department,Semister=request.user.Semister)
        context={
            'title':'Course',
            'course':course
        }
        return render(request,"AllCourses.html",context)
    elif request.user.is_authenticated and request.user.Role=='Admin' or request.user.Role=='Teacher':
        course=Course.objects.all()
        context={
            'title':'Course',
            'course':course
        }
        return render(request,"AllCourses.html",context)
        
    else:
        return redirect('/Account/login/')

def Upload_Course(request):
    if request.user.is_authenticated and request.user.Role=="Admin":
        error=None
        fm=Course_ModelForm(request.POST or None)
        if request.method=='POST':
            if fm.is_valid():
                sub=fm.cleaned_data.get('Subject_name')
                is_Exist=Course.objects.filter(Subject_name=sub).exists()
                if is_Exist:
                    messages.warning(request,'Subject Already exist')
                else:
                    fm.save()
                    messages.success(request,'Course is added successfully')
                    return redirect('/Courses/All Courses/')
            else:
                error=fm.errors
        context={
            'title':'Upload Course',
            'form':fm,
            'error':error,
        }
        return render(request, 'Upload_Course.html',context)
    else:
        return redirect('/Account/login/')

def Assign_Teacher_To_Course(request,id):
    if request.user.is_authenticated and request.user.Role=="Admin":
        get_Teacher=Course.objects.get(pk=id) 
        if request.method=='POST':
            form=Course_TeacherChange_ModelForm(request.POST,instance=get_Teacher)
            if form.is_valid():
                form.save()
                messages.success(request,'Successfully Updated ')
                return redirect('/Courses/All Courses/')
        form=Course_TeacherChange_ModelForm(instance=get_Teacher)
        context={
            'title':'Change Teacher',
            'tt':form,
        }
        return render(request,'Assign_Teacher.html' ,context)
    else:
        return redirect('/Admin/login/')

def My_Courses(request):
    if request.user.is_authenticated and request.user.Role=='Teacher' or request.user.Role == 'Admin' and request.user.Department != None:
        courses=Course.objects.filter(Teacher=request.user.id)
        context={
            'title':'My Courses',
            'cou':courses
        }
        return render(request, 'My_Courses.html', context)
        
    else:
        return redirect('/Account/login/')

def Edit_Course(request,id):
    if request.user.is_authenticated:
        get_id=Course.objects.get(pk=id)
        cform=Course_ModelForm(request.POST,instance=get_id)
        if request.method=='POST':
            cform.save()
            messages.success(request,' Course is Successfully Updated')
            return redirect('/Courses/All Courses/')
        cform=Course_ModelForm(instance=get_id)
        context={
            'form':cform
        }
        return render(request, 'Edit_Course.html',context)
        
    else:
        return redirect('/Account/login/')

def delete_Course(request,id):
    if request.user.is_authenticated:
        get_id=Course.objects.get(pk=id)
        get_id.delete()
        messages.success(request,'Course is Successfully deleted')
        return redirect('/Courses/All Courses/')
    else:
        return redirect('/Account/login/')

def dept(request):
    dept=Department.objects.filter(Department_name=request.user.Department).values()
    return JsonResponse({
        'dept':list(dept)
    })

def tea(request,*args, **kwargs):
    dept=kwargs.get('catagory');
    tea=User.objects.filter(Department__Department_name=dept,Semister =None).values()
    print(tea)
    return JsonResponse({
      'tea':list(tea)  
    })

# def Assign_tea(request,*args, **kwargs):
#     Catagory=kwargs.get('cat')
#     teachers=[]
#     getTeachers=User.objects.filter(Role='Teacher',Department__Department_name=Catagory).values()
#     return JsonResponse({
#         'Tea':list(getTeachers)
#     })

def Edit_cou(request,*args, **kwargs):
    Catagory=kwargs.get('cat')
    getteachers=User.objects.all().filter(Department__Department_name=Catagory,Semister=None).values()
    return JsonResponse({
        'tea':list(getteachers)
    })