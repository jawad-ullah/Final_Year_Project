from django import forms
from core.models import Lecture
class LectureModelForm(forms.ModelForm):
    class Meta:
        model=Lecture
        fields='__all__'
        widgets={
            'lecture_no':forms.TextInput(attrs={'type':'number','class':'form-control'}),
            'Department':forms.Select(attrs={'type':'select','class':'form-control'}),
            'Semister':forms.Select(attrs={'type':'select','class':'form-control'}),
            'LectureFile':forms.FileInput(attrs={'type':'file','class':'form-control'}),
            'Subject':forms.Select(attrs={'type':'select','class':'form-control'}),
            }