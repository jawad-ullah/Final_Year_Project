const PutSub=document.getElementById('id_Subject')
$.ajax({
    type:'GET',
    url:'/Lectures/get_courses/',
    success:(response)=>{
        const Cou=response.data;
        Cou.map(sub=>{
            const option=document.createElement('option')
            option.textContent=sub.Subject_name
            option.setAttribute('value',sub.id)
            option.setAttribute('class','item')
            PutSub.appendChild(option)
        })
    },
    error:(error)=>
    {
        console.log(error);
    }
})
const LecNo=document.getElementById('Lec_no')
PutSub.addEventListener('change',e=>{
console.log(e.target.value);
const sub=e.target.value
document.getElementById('id_lecture_no').setAttribute('value',"")
    $.ajax({
        type:'GET',
        url:`/Lectures/get_lec_no/${sub}/`,
        success:function(response){
            const Data=response.data
            console.log(response.data);
            document.getElementById('id_lecture_no').setAttribute('value',Data+1)
        },
        error:(error)=>
        {
            console.log(error);
        }
    })
})

// Upload Lecture Inputs

const Dept=document.querySelector('#id_Department')
console.log(Dept)
$.ajax({
    type:'GET',
    url:`/Lectures/dept_Json/`,
    success:(response)=>{
        const Data=response.Dept;
        console.log(Data)
        Data.map(d=>{
            const option=document.createElement('option')
            option.textContent=d.Department_name
            option.setAttribute('value',d.id)
            option.setAttribute('class','item')
            Dept.appendChild(option)
        })
    },
    error:(error)=>{
        console.log(error)
    }
})

// const subject=document.querySelector('#id_Subject')
// const sem=document.querySelector('#id_Semister')
// subject.addEventListener('change',e=>{
//     subId=e.target.value
//     console.log(subId)
//     $.ajax({
//         type:'GET',
//         url:`/Lectures/get_sem/${subId}/`,
//         success:(response)=>{
//             Data=response.sem
//             console.log(Data)
//             Data.map(d=>{
//                 const option=document.createElement('option')
//                 option.textContent=d.Semister
//                 option.setAttribute('value',d.Semister)
//                 sem.appendChild(option)
//             })
//         },
//         error:(error)=>{
//             console.log(error)
//         }
//     })
// })