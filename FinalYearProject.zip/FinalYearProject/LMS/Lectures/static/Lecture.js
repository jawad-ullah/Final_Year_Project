const Dept=document.getElementById('id_Department')
const Sem=document.getElementById('id_Semister')
const Cou=document.getElementById('id_Subject')
const S_Text=document.getElementById('sub-text')
$('.ui.dropdown').dropdown('show');

$.ajax({
    type:'GET',
    url:'/Lectures/dept-json/',
    success:function(response)
    {
        Data=response.dept
        console.log(Data)
        Data.map(item=>{
            const options=document.createElement('option')
            options.textContent=item.Department_name
            options.setAttribute('class','item')
            options.setAttribute('value',item.id)
            Dept.appendChild(options)
        })
    },
    error:function(error)
    {
        console.log(error)
    },
})
$.ajax({
        type:'GET',
        url:`/Lectures/sem-json/`,
        success:function(response)
        {
            Data=response.sem
            Data.map(item=>{
                const options=document.createElement('option')
                options.textContent=item.Semister_name
                options.setAttribute('class','item')
                options.setAttribute('value',item.id)
                Sem.appendChild(options)
            })
        },
        error:function(error)
        {
            console.log(error)
        },
    })

const PutSub=document.getElementById('id_Subject')
$.ajax({
    type:'GET',
    url:'/Lectures/get_courses/',
    success:(response)=>{
        console.log(response.data);
        const Cou=response.data;
        console.log(Cou)
        Cou.map(sub=>{
            const option=document.createElement('option')
            option.textContent=sub.Subject_name
            option.setAttribute('value',sub.id)
            option.setAttribute('class','item')
            PutSub.appendChild(option)
        })
    },
    error:(error)=>
    {
        console.log(error);
    }
})
const LecNo=document.getElementById('Lec_no')
PutSub.addEventListener('change',e=>{
console.log(e.target.value);
const sub=e.target.value
document.getElementById('id_lecture_no').setAttribute('value',"")
    $.ajax({
        type:'GET',
        url:`/Lectures/get_lec_no/${sub}/`,
        success:function(response){
            const Data=response.data
            console.log(response.data);
            document.getElementById('id_lecture_no').setAttribute('value',Data+1)
        },
        error:(error)=>
        {
            console.log(error);
        }
    })
})