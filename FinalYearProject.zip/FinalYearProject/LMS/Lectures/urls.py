from django.urls import path
from . import views
urlpatterns = [

    path('Lectures/<int:id>/',views.Lectures, name='lectures'),
    path('Upload Lecture/',views.upload_lecture,name='upload_lecture'),
    path('Lectures/',views.Student_lectures,name='std-lecture'),
    path('Course Lectures/<int:id>/',views.CourseLectures,name='CourseLectures'),
    
    #Json urls
    path('get_courses/',views.get_Courses,name='course-json'),
    path('get_lec_no/<int:sub>/',views.Get_lec_no,name='lec_no_json'),

    path('dept_Json/',views.Dept_Json,name='dept-json'),
    #path('get_sem/<int:Id>/',views.get_sem,name='sem-json'),
    # path('cou-json/<int:sem>/',views.get_json_cou,name='cou-json'),
]
