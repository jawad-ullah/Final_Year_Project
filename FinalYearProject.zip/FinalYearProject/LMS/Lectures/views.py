from django.shortcuts import render,redirect
from  core.models import *
from .forms import LectureModelForm
from django.contrib import messages
from django.http  import JsonResponse
 # Lectures 
def Lectures(request,id):
    if request.user.is_authenticated and request.user.Role=='Teacher' or request.user.Role == 'Admin' and request.user.Department != None:
        lectures=Lecture.objects.filter(Subject_id=id)
        lectureCount=Lecture.objects.filter(Subject_id=id).count()
        context={
            'lectures':lectures,
            'Count':lectureCount,
        }
        return render(request, 'Lectures.html',context)   
    else:
        return redirect('/Account/login/')

def upload_lecture(request):
    if request.user.is_authenticated and request.user.Role=='Teacher'or request.user.Role == 'Admin' and request.user.Department != None:
        error=None
        fm=LectureModelForm(request.POST,request.FILES or None)
        if request.method=='POST':
            if fm.is_valid():
                fm.save()
                messages.success(request,'Lecture is Successfully Added')
                return redirect('/Courses/My Courses/')
            else:
                error=fm.errors
        context={
            'form':fm,
            'error':error
        }
        return render(request, 'Upload_Lecture.html',context)   
    else:
        return redirect('/Account/login/')

def Student_lectures(request):
    if request.user.is_authenticated and request.user.Role=='Student':
        error=None
        courses=Course.objects.filter(Department__id=request.user.Department_id,Semister__id=request.user.Semister_id)
        context={
            'cou':courses,
        }
        return render(request, 'StudentLectures.html',context)   
    else:
        return redirect('/Account/login/')

def CourseLectures(request,id):
    if request.user.is_authenticated and request.user.Role=='Student':
        lectures=Lecture.objects.filter(Subject=id)
        lecCount=Lecture.objects.filter(Subject=id).count()
        context={
            'lec':lectures,
            'Count':lecCount
        }
        return render(request, 'CourseLectures.html',context)   
    else:
        return redirect('/Account/login/')

# #JSON Data
def Dept_Json(request):
    dept=Department.objects.all().filter(Department_name=request.user.Department).values()
    return JsonResponse({
        'Dept':list(dept)
    })

# def get_sem(request,*args, **kwargs):
#     Id=kwargs.get('Id')
#     sem=[]
#     cou=Course.objects.filter(id=Id)
#     for c in cou:
#         item={
#         'Semister':c.Semister.Semister_name,
#         }
#         sem.append(item)

#     return JsonResponse({
#         'sem':sem,
#     })

def get_Courses(request):
    courses=Course.objects.filter(Teacher__email=request.user.email).values()
    print(courses)
    return JsonResponse({
        'data':list(courses)
    })
def Get_lec_no(request,*args, **kwargs):
    Subj=kwargs.get('sub');
    Lectures=Lecture.objects.filter(Subject_id=Subj).values()
    Depat=Lecture.objects.filter()
    print(Lectures)
    return JsonResponse({
        'data':len(list(Lectures))
    })