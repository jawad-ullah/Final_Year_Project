from django import forms
from core.models import User

class ProfileModelForm(forms.ModelForm):
    first_name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'First name',
    }))
    last_name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Last name',
    }))
    Father_Name=forms.CharField(max_length=50,required=True,widget=forms.TextInput(attrs={
        'class':'form-control',
        'type':'text',
        'placeholder':'Last name',
    }))
    email=forms.CharField(max_length=100,help_text='email',required=True,widget=forms.EmailInput(attrs={
        'class':'form-control',
        'type':'email',
        'placeholder':'Email',
    }))
    class Meta:
        model=User
        fields=['first_name','last_name','Father_Name','email','Department','Semister','Address','contact_no','Profile_Img']
        widgets={
            'Department':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Semister':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Address':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'contact_no':forms.TextInput(attrs={'class':'form-control','type':'text'}),
            'Role':forms.RadioSelect(),
        }