from django.urls import path
from . import views

urlpatterns=[
    path('User Profile/<int:id>/',views.Profile, name='user_profile'),
    path('Edit Profile/<int:id>/',views.Edit_Profile,name='Edit_profile'),
    path('Profile/',views.Back,name='back'),
]