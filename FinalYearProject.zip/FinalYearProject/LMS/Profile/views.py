from django.shortcuts import render,redirect
from core.models import User
from .forms import ProfileModelForm
from django.contrib import messages
# Create your views here.
def Profile(request,id):
    if request.user.is_authenticated:
        get_use_id=User.objects.get(pk=id)
        context={
            'user':get_use_id
        }
        return render(request,'Profile.html',context)
    else:
        return redirect('/Account/login/')


def Edit_Profile(request,id):
    if request.user.is_authenticated:
        error=None
        get_id=User.objects.get(pk=id)
        if request.method == "POST":
            fm=ProfileModelForm(request.POST,request.FILES,instance=get_id)
            if fm.is_valid():
                fm.save()
                messages.success(request,"User is Successfully Updated")
                return redirect('/Profile/Profile/')
            else:
                error=fm.errors
        fm=ProfileModelForm(instance=get_id)
        context={
            'form':fm,
            'error':error
        }
        return render(request,'Edit_profile.html',context)
    else:
        return redirect('/Account/login/')

def Back(request):
    if request.user.is_authenticated and request.user.Role=='Teacher':
        return redirect('/Teacher/Teacher_Dashboard/')
    elif request.user.is_authenticated and request.user.Role=='Student':
        return redirect('/Student/Student_Dashboard/')
    elif request.user.is_authenticated and request.user.Role=='Admin':
        return redirect('/Admin/Admin Dashboard/')
    else:
        return redirect('/')