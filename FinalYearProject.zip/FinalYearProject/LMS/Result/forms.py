from django import forms
from django.core.exceptions import ValidationError
from core.models import User,Result,SessionModel

class ResutlForm(forms.ModelForm):
    """Form definition for Resutl."""

    class Meta:
        model = Result
        fields = '__all__'
        widgets={
            'Session':forms.Select(attrs={'class':'form-control'}),
            'result_type':forms.Select(attrs={'class':'form-control','type':'select'}),
            'Department':forms.Select(attrs={'class':'form-control'}),
            'Semister':forms.Select(attrs={'class':'form-control'}),
            'Result':forms.FileInput(attrs={'class':'form-control','type':'file'}),
            
        } 
        
class SessionModelsForm(forms.ModelForm):
    class Meta:
        model=SessionModel
        fields='__all__'
        widgets={
            'Session':forms.TextInput(attrs={
                'class':'form-control',
                'type':'text',
                'placeholder':'Enter Session (Spring 2021)',
            })
        }
