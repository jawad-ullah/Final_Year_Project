from django.db import models
from core.models import Result