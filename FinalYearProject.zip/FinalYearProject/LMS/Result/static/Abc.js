const result=document.getElementById('selDpet');
const putData=document.getElementById('Puts');
const res=document.getElementById('ResType');
const Dept = document.getElementById('id_Department')
const Sem = document.getElementById('id_Semister')
const textcontent=document.getElementById('text_centent');

$.ajax({
    type: 'GET',
    url: '/Result/dept-json/',
    success: function (response) {
        Data = response.dept
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Department_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Dept.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})

// Result Dashboard Ajax
var sessId=0;
var rst;
const Session=document.querySelector('.sess')
const Res=document.querySelector('.RsType')
const deptt=document.querySelector('.getDept')
const putResult=document.querySelector('.PutRes')
Session.addEventListener('change',e=>{
    Res.innerHTML=""
    sessId=e.target.value;
    putResult.innerHTML=""
    const option1=document.createElement('option')
    const option2=document.createElement('option')
    const option3=document.createElement('option')
    option1.textContent='---------'
    option2.textContent='Final term';
    option3.textContent='Mid term'
    option1.setAttribute('value','')
    option2.setAttribute('value','Final')
    option3.setAttribute('value','Mid')
    Res.append(option1)
    Res.append(option2)
    Res.append(option3)
})
Res.addEventListener('change',e=>{
    rst=e.target.value;
    deptt.innerHTML=""
    const option=document.createElement('option')
    option.textContent='---------'
    option.setAttribute('value',"")
    deptt.appendChild(option)
    $.ajax({
        type:'GET',
        url:`/Result/get_all_Dept_json/`,
        success:(response)=>{
            Deptt=response.obj;
            Deptt.map(d=>{
                const option=document.createElement('option')
                option.textContent=d.Department_name;
                option.setAttribute('value',d.id)
                deptt.appendChild(option)
            })
        },
        error:(error)=>{
            console.log(error)
        }
    })
})
deptt.addEventListener('change',e=>{
    res_obj=e.target.value;
    console.log(res_obj)
    putResult.innerHTML=""
    $.ajax({
        type:'GET',
        url:`/Result/get_res_json/${sessId}/${rst}/${res_obj}/`,
        success:(response)=>{
            Result=response.obj;
            if (Result != "")
            {
                for (var i = 0; i < Result.length; i++) {
                    putResult.innerHTML+=`
                    <ul>
                        <li>Result for ${Result[i].Department} ${Result[i].Semister} Semister <a href="${Result[i].Result}">Click here <i class="fa fa-eye"></i></a></li>
                    </ul>
                    `
                }
            }
            else{
                putResult.innerHTML=
                `
                    <p class="text-center mt-5">
                        <p class="p-2 border-bottom shadow-lg">
                        <strong class="text-danger">Sorry!</strong>
                         Result is Not Uploaded.Please wait for new Updates</p>
                    </p>
                `
            }
            
        },
        error:(error)=>{
            console.log(error)
        }
    })
})


$.ajax({
    type: 'GET',
    url: '/Result/sem-json/',
    success: function (response) {
        Data = response.sem
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Semister_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Sem.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})

result.addEventListener('change',e=>{
    const Value=e.target.value
    putData.textContent=""
    $.ajax({
        type:'GET',
        url:`/Result/disp_res/${Value}/`,
        success:(response)=>{
            data=response.data;
            console.log(response.data);
            data.map(r=>{
                const option=document.createElement('option')
                option.textContent=r.result_type+' Result for '+r.Department+' '+ r.Semister+' Semester Session ('+r.Session+')';
                option.setAttribute('value',r.id);
                option.setAttribute('class','item');
                res.appendChild(option)
            })
        },
        error:(error)=>{
            console.log(error)
        }
    })

})
res.addEventListener('change',e=>{
    console.log(e.target.value)
    putData.textContent=""
    const res=e.target.value
    console.log(res);
    $.ajax({
        type:'GET',
        url:`/Result/ret-res/${res}/`,
        success:(response)=>{
            const Data=response.Data
            if(Data)
            {
            Data.forEach(ele => {
                console.log(ele.result_type)
                if (ele.result_type == 'Final')
                {
                putData.innerHTML +=
                `
                <tr>
                <td>${ele.Session}</td>
                <td>${ele.Department}</td>
                <td>${ele.Semister}</td>
                <td>${ele.result_type}</td>
                <td><a href="${ele.Result}">View</a></td>
                <tr>
                `
                }
                else if (ele.result_type == 'Mid')
                {
                putData.innerHTML +=
                `
                <tr>
                <td>${ele.Session}</td>
                <td>${ele.Department}</td>
                <td>${ele.Semister}</td>
                <td>${ele.result_type}</td>
                <td><a href="${ele.Result}">View</a></td>
                <tr>
                `
                }
             
            }); 
            }
            else if(Data==""){
                putData.innerHTML=
                `
                <div class="text-center">
                    <h2 class="text-danger text-center">Sorry</h2>
                    <p class="text-danger">Result is Not Uploaded yet</p>
                </div>
                `
            }   

        },
        error:(error)=>{
            console.log(error);
        }
    })
})