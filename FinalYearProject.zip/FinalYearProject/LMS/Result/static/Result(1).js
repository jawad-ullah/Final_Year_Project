$(document).ready(function(){
    $('#DataTable').DataTable()
})
const Dept = document.getElementById('id_Department')
const Sem = document.getElementById('id_Semister')
const Std = document.getElementById('id_Student')
const form_Group = document.getElementById('form-group')
$.ajax({
    type: 'GET',
    url: '/Result/dept-json/',
    success: function (response) {
        Data = response.dept
        console.log(Data)
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Department_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Dept.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})

/*Semister Values */
$.ajax({
    type: 'GET',
    url: '/Result/sem-json/',
    success: function (response) {
        Data = response.sem
        console.log(Data)
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Semister_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Sem.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})
var sel = 0;
function DepartSelect(e) {
    sel = e
    console.log(sel)
}

function SemSelect(e) {
    dept = sel
    sem = e
    console.log(dept)
    console.log(sem)
    $.ajax({
        type: 'GET',
        url: `/Result/std-json/${dept}/${sem}/`,
        success: function (data) {
            Data = data.std
            CouData = data.cou
            console.log(CouData)
            console.log(Data)
            Data.map(item => {
                const option = document.createElement('option')
                option.textContent = item.username
                option.setAttribute('class', 'item')
                option.setAttribute('value', item.id)
                Std.appendChild(option)
            })
            var i = 1;
            CouData.map(item => {
                const label = document.createElement('label')
                label.textContent = item.Subject_name
                const input = document.createElement('input')
                input.setAttribute('type', 'text')
                input.setAttribute('id', item.Subject_name)
                input.setAttribute('name', `Subject${i++}`)
                input.setAttribute('class', 'form-control')
                input.setAttribute('placeholder', 'Enter marks')
                form_Group.appendChild(label)
                form_Group.appendChild(input)

            })
        },
        error: function (error) { console.log(error) }
    })
}

/*Checking Result and it's options */
