$(document).ready(function(){
    $('#DataTable').DataTable()
})
console.log("HI Result")
const Dept = document.getElementById('id_Department')
const Sem = document.getElementById('id_Semister')
const Std = document.getElementById('id_Student')
const form_Group = document.getElementById('form-group')
const semtext=document.getElementById('SemText')
$.ajax({
    type: 'GET',
    url: '/Result/dept-json/',
    success: function (response) {
        Data = response.dept
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Department_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Dept.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})

/*Semister Values */
$.ajax({
    type: 'GET',
    url: '/Result/sem-json/',
    success: function (response) {
        Data = response.sem
        Data.map(item => {
            const option = document.createElement('option')
            option.textContent = item.Semister_name
            option.setAttribute('value', item.id)
            option.setAttribute('class', 'item')
            Sem.appendChild(option)
        })
    },
    error: function (error) {
        console.log(error)
    }
})
var sel = 0;
function DepartSelect(e) {
    sel = e
    console.log(sel)
}

function SemSelect(e) {
    dept = sel
    sem = e
    console.log(dept)
    console.log(sem)
    form_Group.innerHTML=""
    $.ajax({
        type: 'GET',
        url: `/Result/std-json/${dept}/${sem}/`,
        success: function (data) {
            Data = data.std
            CouData = data.cou
            console.log(CouData)
            console.log(Data)
            Data.map(item => {
                const option = document.createElement('option')
                option.textContent = item.username
                option.setAttribute('class', 'item')
                option.setAttribute('value', item.id)
                Std.appendChild(option)
            })
            var i = 1;
            CouData.map(item => {
                const label = document.createElement('label')
                label.textContent = item.Subject_name
                const input = document.createElement('input')
                input.setAttribute('type', 'text')
                input.setAttribute('id', item.Subject_name)
                input.setAttribute('name', `Subject${i++}`)
                input.setAttribute('class', 'form-control')
                input.setAttribute('placeholder', 'Enter marks')
                form_Group.appendChild(label)
                form_Group.appendChild(input)

            })
        },
        error: function (error) { console.log(error) }
    })
}

/*Checking Result and it's options */

const result=document.getElementById('selDpet');
console.log(result)
const putData=document.getElementById('Puts');
console.log(putData);
result.addEventListener('change',e=>{
    putData.textContent=""
    Value=e.target.value
    $.ajax({
        type:'GET',
        url:`/Result/res-json/${Value}/`,
        success:function(response)
        {
            const Data=response.data;
            if(Data)
            {
            Data.forEach(ele => {
                console.log(ele.result_type)
                if (ele.result_type == 'Final')
                {
                putData.innerHTML +=
                `
                <tr>
                <td>${ele.Session}</td>
                <td>${ele.Department}</td>
                <td>${ele.Semister}</td>
                <td>${ele.result_type}</td>
                <td><a href="${ele.Result}">View</a></td>
                <td><a href="/Result/Delete Result/${ele.id}">Delete</a></td>
                <tr>
                `
                }
                else if (ele.result_type == 'Mid')
                {
                putData.innerHTML +=
                `
                <tr>
                <td>${ele.Session}</td>
                <td>${ele.Department}</td>
                <td>${ele.Semister}</td>
                <td>${ele.result_type}</td>
                <td><a href="${ele.Result}">View</a></td>
                <tr>
                `
                }
             
            }); 
            }
            else if(Data==""){
                putData.innerHTML=
                `
                <div class="text-center">
                    <h2 class="text-danger text-center">Sorry</h2>
                    <p class="text-danger">Result is Not Uploaded yet</p>
                </div>
                `
            }   
        },
        error:function(error)
        {
            console.log(error)
        },
    })
})

const res=document.getElementById('Result_id')
console.log("Hi Result")
console.log(res)
res.addEventListener('change',e=>{
    console.log(e.target.value)
})

//Student Result get Json Department
const Dept=document.getElementById('selDpet')
console.log(Dept);
$.ajax({
    type:'GET',
    url:'/Result/get_dept/',
    success:(response)=>{
        console.log(response.data);
        Data=response.data
        Data.map(d=>{
            const option=document.createElement('option')
            option.setAttribute('value',Data.id)
            option.setAttribute('class','item')
            Dept.appendChild(option)
        })
    },
    error:(error)=>{
        console.log(error);
    }
})

const De=document.getElementById("selDpet");
console.log(De);