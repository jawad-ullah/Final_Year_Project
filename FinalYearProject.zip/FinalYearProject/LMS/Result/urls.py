from django.urls import path
from . import views
urlpatterns=[
    path('Dashboard/',views.Dashboard,name='Result_Dashboard'),
    path('Upload Result/',views.Results,name='result'),
    path('View Result/<int:id>/',views.DeptList,name="DeptList"),
    path('Session/',views.Session,name='Session'),
    path('UploadSession/',views.uploadSession,name='Upload_session'),
    path('Session Detail/<int:id>/',views.sessionDetail,name="SessionDetail"),
    path('Session Delete/<int:id>/',views.SessionDelete,name="SessionDelete"),
    path('Detail/<int:id>/',views.DetailResult,name='Detail_result'),
    path('Delete Result/<int:id>/',views.DeleteResult,name="Delete_Result"),

    #Student Result
    path('Student Result/',views.Student_Result,name='std_result'),
    #Student-result-json
    path('get_dept/',views.get_deptt_json,name="dept-json"),
    #Result Json
    path('dept-json/',views.get_dept_json,name='std-json'),
    path('sem-json/',views.get_sem_json,name='sem-json'),
    path('get_res_json/<str:sess>/<str:rs>/<int:dept>/',views.Resultss,name="res-type"),
    path('std-json/<str:d>/<str:s>/',views.get_std_json,name='std-json'),
    path('get_all_Dept_json/',views.get_all_dept,name='all_dept'),
    # path('res-json/<int:Dept>/',views.getResult,name='res-json'),
    path('disp_res/<int:Dept>/',views.DispResult,name='dres-json'),
    path('ret-res/<int:result>/',views.RetieveResult,name='ret-res'),
]
