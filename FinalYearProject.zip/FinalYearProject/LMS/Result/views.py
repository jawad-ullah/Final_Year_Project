from functools import reduce
from os import terminal_size
from django.core.exceptions import ValidationError
from django.shortcuts import render,redirect
from core.models import Result,Department,Semister,User,Course,SessionModel,Result
from django.http import JsonResponse
from .forms import ResutlForm,SessionModelsForm
from django.contrib import messages
# from Student.models import Student
def Dashboard(request):
    if request.user.is_authenticated:
        session=SessionModel.objects.filter(Approve=True)
        context={
            'title':'Dashboard',
            'session':session
        }
        return render(request, 'Result_Dashboard.html', context)
    else:
        return redirect('/Account/login/')

def Results(request):
    error=None
    if request.user.is_authenticated:
        R_form=ResutlForm(request.POST,request.FILES or None)
        if request.method=="POST":
            if R_form.is_valid():
                sess=R_form.cleaned_data.get('Session')
                dept=R_form.cleaned_data.get('Department')
                sem=R_form.cleaned_data.get('Semister')
                result=R_form.cleaned_data.get('result_type')
                is_Exist=Result.objects.filter(Session=sess,result_type=result,Department=dept,Semister=sem).exists()
                if is_Exist:
                    messages.warning(request,'You have already uploaded. Try another!')
                else:
                    R_form.save()
                    messages.success(request,'Result is Successfully added')
                    return redirect('/Result/Dashboard/')
            else:
                error=R_form.errors
        context={
            'title':'Result',
            'R_form':R_form,
            'error':error,
        }
        return render(request, 'Result.html', context)
    else:
        return redirect('/Account/login/')

def ResutlCheckingOptions(request):
    if request.user.is_authenticated:
        context={}
        return render(request,'ResutlCheckingOptions.html',context)
    else:
        return redirect('/Account/login/')

def DeptList(request,id):
    if request.user.is_authenticated:
        session=SessionModel.objects.all().filter(Approve=True)
        session_object=SessionModel.objects.get(id=id)
        print(session_object)
        context={
            'session':session,
            'sess_obj':session_object
            }
        return render(request,'View_Result.html', context)
    else:
        return redirect('/Account/login/')

def DetailResult(request,id):
    result=Result.objects.filter(pk=id)
    context={
        'res':result
    }
    return render(request,'DetailResult.html',context)

def DeleteResult(request,id):
    if request.user.is_authenticated:
        getId=Result.objects.get(pk=id)
        getId.delete()
        messages.success(request,'Result is successfully deleted')
        return redirect('/Result/Dashboard/')
    else:
        return redirect('/Account/login/')


def Session(request):
    if request.user.is_authenticated and request.user.Role == 'Admin' and request.user.Department == None:
        sess_obj=SessionModel.objects.all()
        context={
            'obj':sess_obj
        }
        return render(request,'Sess.html',context)
    else:
        return redirect('/Account/login/')
def uploadSession(request):
    if request.user.is_authenticated:
        error=None
        fm=SessionModelsForm(request.POST or None)
        if request.method=='POST':
            if fm.is_valid():
                fm.save()
                messages.success(request,'Session is Addded Successfully')
                return redirect('/Result/Session/')
            else:
                error=fm.errors
        context={
            'form':fm,
            'error':error
            }

        return render(request,'uploadSession.html',context)
    else:
        return redirect('/Account/login/')

def sessionDetail(request,*args, **kwargs):
    Id=kwargs.get('id')
    session_obj=SessionModel.objects.get(id=Id)
    form=SessionModelsForm(instance=session_obj)
    if request.method == 'POST':
        fm=SessionModelsForm(request.POST,instance=session_obj)
        if fm.is_valid():
            fm.save()
            messages.success(request,'Session is Updated Successfully')
            return redirect('/Result/Session/')
    context={
        'form':form
    }
    return render(request,'sessionDetail.html',context)

def SessionDelete(request,*args, **kwargs):
    Id=kwargs.get('id')
    get_object=SessionModel.objects.get(id=Id)
    get_object.delete()
    messages.success(request,f"Session {get_object.Session} is deleted Successfully")
    return redirect('/Result/Session/')
    pass
# Student Result
def Student_Result(request):
    if request.user.is_authenticated and request.user.Role=='Student':
        context={
            'title':'Result'
        }
        return render(request,'Student_Result.html',context)
    else:
        return redirect('/Account/login/')

# Student Ajax json
def get_deptt_json(request):
    dept=Department.objects.filter().values()
    return JsonResponse({
        'data':list(dept)
    })


#Ajax Json
def get_dept_json(request):
    if request.user.is_authenticated:
        dept=list(Department.objects.filter(Department_name=request.user.Department).values())
        return JsonResponse({
            'dept':dept,
        })
def get_sem_json(request):
    if request.user.is_authenticated:
        sem=list(Semister.objects.values())
        return JsonResponse({
            'sem':sem,
        })
def get_std_json(request,*args,**kwargs):
    if request.user.is_authenticated:
        Dept=kwargs.get('d')
        Sem=kwargs.get('s')
        std=list(User.objects.filter(Role='Student',Department=Dept,Semister=Sem).values())
        cou=list(Course.objects.filter(Department=Dept,Semister=Sem).values())
        return JsonResponse(data={
            'std':std,
            'cou':cou,
        })
       
    
def DispResult(request,*args, **kwargs):
    dres=kwargs.get('Dept')
    Rlt=[]
    Res=Result.objects.filter(Department_id=dres)
    for r in Res:
        item={
            'id':r.id,
            'Result':r.Result.url,
            'Department':r.Department.Department_name,
            'Semister':r.Semister.Semister_name,
            'Session':r.Session.Session,
            'result_type':r.result_type,
        }
        Rlt.append(item)
    return JsonResponse({
        'data':Rlt
    })

def get_all_dept(request):
    dept_obj=Department.objects.all().values()
    return JsonResponse({
        'obj':list(dept_obj)
    })

def RetieveResult(request,*args, **kwargs):
    r=kwargs.get('result')
    Rlt=[]
    Res=Result.objects.all().filter(pk=r)
    for r in Res:
        item={
            'id':r.id,
            'Result':r.Result.url,
            'Department':r.Department.Department_name,
            'Semister':r.Semister.Semister_name,
            'Session':r.Session.Session,
            'result_type':r.result_type,
        }
        Rlt.append(item)
    return JsonResponse({
        'Data':Rlt
    })


def Resultss(request,rs,sess,dept):
    res_obj=Result.objects.all().filter(result_type=rs,Session=sess,Department=dept)
    Res_Objects=[]
    for rs in res_obj:
        item={
            'id':rs.id,
            'Result':rs.Result.url,
            'Department':rs.Department.Department_name,
            'Semister':rs.Semister.Semister_name,
            'Session':rs.Session.Session,
            'result_type':rs.result_type,
        }
        Res_Objects.append(item)
    return JsonResponse({
        'obj':Res_Objects
    })
