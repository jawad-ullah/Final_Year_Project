from django import forms
from core.models import TimeTable

class TimeTableModelForm(forms.ModelForm):
    class Meta:
        model=TimeTable
        fields='__all__'
        widgets={
            'TimeTable':forms.FileInput(attrs={'type':'file','class':'form-control'}),
            'Department':forms.Select(attrs={'type':'select','class':'form-control'})
            
            }