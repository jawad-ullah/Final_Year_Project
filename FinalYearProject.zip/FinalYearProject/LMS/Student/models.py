from django.db import models
# Create your models here.
class Student(models.Model):
    # user = models.OneToOneField(User, on_delete=models.CASCADE,primary_key=True,related_name='students')
    # Father_Name=models.CharField(max_length=100,null=True)
    # Department= models.ForeignKey(Department,  on_delete=models.CASCADE,null=True)
    # Semister=models.ForeignKey(Semister, on_delete=models.CASCADE,null=True)
    # Address=models.TextField(max_length=255,null=True)
    # Date_of_Birth=models.DateField(null=True)
    # Image=models.ImageField(upload_to='profile',default='no_img')
    # created=models.DateTimeField(auto_now_add=True),

    # def __str__(self):
    #     return self.user.username
    pass