  /* DataTables*/
  $(document).ready( function () {
    $('#DataTable').DataTable();
} );

const students=[...document.getElementsByClassName('std')]
console.log(students);

students.forEach(std=>{
  std.style.height="200px";
  std.style.backgroundColor='wheat';
  std.style.marginLeft='10px';
  std.style.borderRadius='10px'
  std.style.marginTop='5px';
})

const Dp=[...document.getElementsByClassName('dp')]
console.log(Dp)
Dp.forEach(p=>{
  p.style.border="1px solid white";
  p.style.backgroundColor="wheat";
  p.style.padding='25px';
  p.style.borderRadius='100%';
  p.style.marginTop='20px';
})
const Link=[...document.getElementsByClassName('link')]
Link.forEach(l=>{
  l.style.marginTop="45px";
  l.style.border="2px solid white";
  l.style.display='inline-block';
  l.style.paddingLeft='15px';
  l.style.paddingRight='15px';
  l.style.borderRadius='50%';
  l.style.backgroundColor='wheat'
})
