from django.urls import path
from . import views
urlpatterns = [
    path('Student_Dashboard/',views.stdDashboard,name='stdDashboard'),
    path('Students/',views.Students,name='Std'),
    path('Edit student/<int:id>/',views.Edit_student,name='E_Student'),
    path('Delete Student/<int:id>/',views.Delete_Student,name='D_Student'),
    path('TimeTable/',views.Student_TimeTable,name='Student_TimeTable'),
    path('Study_Scheme/',views.Study_Scheme,name='Study_Scheme'),
    path('Lectures/',views.Student_lectures,name='stdlectures'),
    path('delete student/<int:id>/',views.delStudent,name="delStudent")
]
