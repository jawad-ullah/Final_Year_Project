from django.shortcuts import render,redirect
from Student.models import Student
from .forms import TimeTableModelForm
from django.contrib import messages
from core.models import *
from Admin.forms import Edit_UserForm
# Rendering  Dashbaoared
def stdDashboard(request):
    if request.user.is_authenticated:
        Cou=Course.objects.all().filter(Department__Department_name=request.user.Department).count()
        Ass=Assignment.objects.all().count()
        Res=Result.objects.filter().count()
        context={'title':'Dashboard',
                'Cou':Cou,
                'Ass':Ass,
                'Res':Res,
        }
        return render(request,'Student_Dashboard.html',context)
    else:
        return redirect('/Account/login/')

def Students(request):
    if request.user.is_authenticated:
        if request.user.Role =='Admin' and request.user.Department != None:
            std=User.object.all().filter(Role="Student",Department=request.user.Department)
            context={
                'std':std
            }
        elif request.user.Role=='Admin' and request.user.Department==None:
            std=User.object.all().filter(Role="Student")
            context={
                'std':std
            }
        if request.user.Role =='Teacher':
            std=User.object.all().filter(Role="Student",Department=request.user.Department)
            context={
                'std':std
            }
        return render(request,'Students.html',context)
    else:
        return redirect('/Account/login/')

def Edit_student(request,id):
    if request.user.is_authenticated:
        get_id=User.objects.get(pk=id)
        sform=Edit_UserForm(request.POST,request.FILES,instance=get_id)
        if request.method=="POST":
            if sform.is_valid():
                sform.save()
                messages.success(request,'Successfully Updated')
                return redirect('/Student/Student_Dashboard/')
        sform=Edit_UserForm(instance=get_id)
        context={
            'form':sform
        }
        return render(request, 'Edit_Student.html',context)
        
    else:
        return redirect('/Account/login/')

def Delete_Student(request,id):
    if request.user.is_authenticated:
        get_id=User.objects.get(pk=id)
        get_id.delete()
        messages.success(request,f"{get_id.username} is Successfully deleted")
        return redirect('/Student/Student_Dashboard/')
    else:
        return redirect('/Account/login/')


# Time table View
def Student_TimeTable(request):
    tiemtable=TimeTable.objects.all()
    dept=Department.objects.filter(id=1)
    Department_Course=[]
    for d in dept:
        course=[]
        for c in d.get_courses():
            course.append(c)
        Department_Course.append({str(d):course})
    context={
        'title':'TimeTabel',
        'fm':tiemtable,
        'form':Department_Course,
    }
    return render(request,'Student_TimeTable.html',context)


def Study_Scheme(request):
    if request.user.is_authenticated:
        outline=Course_Outline.objects.all()
        context={
            'title': 'Study Scheme',
            'outline':outline,
        }
        return render(request, 'Study_Scheme.html',context)
    else:
        return redirect('/Account/login/')

def Student_lectures(request):
    if request.user.is_authenticated:
        courses=Course.objects.filter(Department=request.user.Department,Semister=request.user.Semister)
        context={
            'courses':courses,
        }
        return render(request, 'StudentLectures.html',context)
    else:
        return redirect('/Account/login/')

def delStudent(request,id):
    if request.user.is_authenticated:
        user_obj=User.objects.get(id=id)
        user_obj.delete()
        messages.success(request,'Student is Successfully deleted')
        return redirect('/Student/Students/')

