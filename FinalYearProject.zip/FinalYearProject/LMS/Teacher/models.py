from django.db import models
# from core.models import User,Department,Semister
# Create your models here.
