function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
/*ColorBox */
$('.teacher_Img').colorbox({
  'rel': 'img',
  transition: 'fadeIn',
  scalePhotos: true,
  width: '500px',
  height: '500px',
  maxHeight: '100%',
  maxWidth: '100%',
  top: '20px',

})

$(document).ready(function () {
  $('#DataTable').DataTable();
});
$(document).ready(function () {
  $('#Course_DataTable').DataTable();
});
console.log("Teacher")
$(document).ready(function(){
  
const Dept=document.getElementById('id_Department')
const Subj=document.getElementById('id_Subject')
// const subText=document.getElementById('sub-text')

// subText.innerHTML=""
// subText.textContent='Choose Subject'

$.ajax({
  type:'GET',
  url :'/Teacher/dept-json/',
  success:function(respose)
  {
    Data=respose.dept
    Data.map(item=>{
      const option=document.createElement('option')
      option.textContent=item.Department_name
      option.setAttribute('class','item')
      option.setAttribute('value',item.id)
      Dept.appendChild(option)
    })
  }
})
Dept.addEventListener('change',e=>{
  console.log(e.target.value)
  dept=e.target.value
  $.ajax({
    type:'GET',
    url:`/Teacher/subject-json/${dept}`,
    success:function(data){
      Data=data.sub
      Data.map(item=>{
        const option=document.createElement('option')
        option.textContent=item.Subject_name
        option.setAttribute('class','item')
        option.setAttribute('value',item.id)
        Subj.appendChild(option)
      })
      
    },
    error:function(error){
      console.log(error)
    },
  })
 
})

})
// Teacher Dashboard
// const  navEv=document.getElementById('navEvent');
// navEv.addEventListener('click',()=>{
//   console.log("Clicked")
//   $.ajax({
//     type:'GET',
//     url:'/Teacher/teachers-json/',
//     success:function(data)
//     {
//       teacher=data.user
//       console.log(teacher)
//       for(i=0; i < teacher.length; i++)
//       {
//         $('#tea').append(
//           `
//             <p>${teacher[i].username}</p>
//             <img src="${teacher[i].Profile_Img}/" >
//           `
//         )
//       }
//     },
//     error:function(error)
//     {
//       console.log(error)
//     }
//   })
// })

console.log('Ready!')
const Lectures=document.getElementById('lecture')
const Jawad=document.getElementById('jawad')
Lectures.addEventListener('change',e=>{
  console.log(e.target.value)
  lec=e.target.value
  $.ajax({
    type:'GET',
    url:`/Teacher/get-lect/${lec}/`,
    success:function(respose){
      console.log(respose.lec)
      Lec=respose.lec
      console.log(Lec.length)
      for(var i=0;i<Lec.length; i++)
      {
        Jawad.innerHTML=
          `
          <p>${Lec[i].lecture_no}</p>
          <p>${Lec[i].created}</p>
          <p>${Lec[i].LectureFile}</p>
          <p>${Lec[i].Department}</p>

          `
        
      }
    },
    error:function(error)
    {
      console.log(error)
    }
  })
})