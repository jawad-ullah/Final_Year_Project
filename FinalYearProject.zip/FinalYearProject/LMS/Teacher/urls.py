from django.urls import path
from . import views
urlpatterns = [
    path('Teacher_Dashboard/',views.TeaDashboard,name='Tea_Dashboard'),
    path('Timetable/',views.timetable,name='timetable'),
    path('Teachers/',views.All_Teachers ,name='Teachers'),
    path('Delete Teacher/<int:id>/', views.Del_Teacher,name='delTeacher'),
    path('Edit Teacher/<int:id>/',views.Edit_Teacher,name='EditTeacher'),
    
    path('dept-json/',views.get_dept_json,name='dept-json'),
    path('subject-json/<str:dept>/',views.get_sub_json,name='subject-json'),
    path('get-lect/<str:lec>/',views.get_lec,name='get-lect'),
]
