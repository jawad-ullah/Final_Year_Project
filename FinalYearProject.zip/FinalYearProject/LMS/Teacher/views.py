from django.shortcuts import render,redirect
from core.models import TimeTable,Course,Assignment,Department,Semister,Lecture,User
from django.contrib import messages
import pandas as pd
from Admin.forms import Edit_UserForm
from django.http import JsonResponse
# Rendering  Dashbaoared
def TeaDashboard(request):
    if request.user.is_authenticated and request.user.Role=='Teacher':
        teachers=User.objects.filter(Role="Teacher",Department=request.user.Department).count()
        student=User.objects.filter(Role='Student',Department=request.user.Department).count()
        courses=Course.objects.all().filter(Department=request.user.Department).count()
        context={
            'title':'Dashboard',
            'student':student,
            'teachers':teachers,
            'courses':courses,
            }
        return render(request,'Teacher_Dashboard.html',context)
    else:
        if request.user.Role=='Admin':
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect('/Student/Student_Dashboard/')
        else:
            return redirect('/Teacher/Teacher_Dashboard/')
# Time tables
def timetable(request):
    timetables=TimeTable.objects.all()
    context={
        'title':'timetables',
        'timetable':timetables
        }
    return render(request,'Teacher_Timetable.html',context)
    
    #All Teacher
def All_Teachers(request):
    if request.user.is_authenticated:
        if request.user.Role == "Admin" and request.user.Department != None:
            teachers=User.objects.filter(Department=request.user.Department,Semister=None)
            context={
                'title':'Teachers',
                'teachers':teachers
            }
            return render(request, 'Teachers.html', context)
        elif request.user.Role == "Admin" and request.user.Department == None:
            teachers=User.objects.filter(Role='Teacher')
            context={
            'title':'Teachers',
            'teachers':teachers
        }
            return render(request, 'Teachers.html', context)
        elif request.user.Role == "Teacher":
            teachers=User.objects.filter(Department=request.user.Department,Semister=None)
            context={
            'title':'Teachers',
            'teachers':teachers
        }
            return render(request, 'Teachers.html', context)
        
    else:
        return redirect('/Account/login/')

def Edit_Teacher(request,id):
    if request.user.is_authenticated and request.user.Role=="Admin":
        teachers=User.objects.get(pk=id)
        uform=Edit_UserForm(request.POST ,request.FILES,instance=teachers)
        if request.method=='POST':
            if uform.is_valid():
                Depart=uform.cleaned_data.get('Department')
                exist=User.objects.filter(
                    Department=uform.cleaned_data.get('Department'),
                    Role=uform.cleaned_data.get('Role'),
                    email=uform.cleaned_data.get('email'),
                    ).first()
                if exist:
                    messages.warning(request,f'Admin of {Depart} has already taken.')
                    return redirect('/Teacher/Teachers/')
                else:
                    uform.save()
                    messages.success(request,'Teacher is Updated Successfully')
                    return redirect('/Teacher/Teachers/')
        uform=Edit_UserForm(instance=teachers)
        context={
            'title':'Teachers',
            'uform':uform,
        }
        return render(request, 'Edit_Teacher.html', context)
    else:
        return redirect('/Account/login/')
def Del_Teacher(request,id):
    if request.user.is_authenticated:
        teacher=User.objects.get(pk=id)
        teacher.delete()
        messages.success(request,"Teacher is Successfully Deleted")
        return redirect('/Teacher/Teachers/')
    else:
        return redirect('/Account/login/')
 

def get_dept_json(request):
    if request.user.is_authenticated:
        dept=list(Department.objects.values())
        return JsonResponse({
            'dept':dept
        })
    else:
        return redirect('/Account/login/')

def get_sub_json(request, *args, **kwargs):
    if request.user.is_authenticated:
        dept=kwargs.get('dept')
        print(dept)
        subj=list(Course.objects.filter(Department__id=dept).values())
        dept=list(Department.objects.filter(Department_name=dept).values())
        sem=list(Semister.objects.values())
        return JsonResponse(data={
                'dept':dept,
                'sem':sem,
                'sub':subj,
            })


def get_lec(request,*args,**kwargs):
    if request.user.is_authenticated:
        get_lec=kwargs.get('lec')
        lectures=list(Lecture.objects.filter(Subject__id=get_lec).values())
        print(lectures)
        return JsonResponse({
            'lec':lectures
        })
    else:
        return redirect('/Account/login/')