from django import forms
from .models import Contact

class ContactModelForm(forms.ModelForm):
    class Meta:
        model=Contact
        fields='__all__'
        widgets={   
            'First_name':forms.TextInput(attrs={
                'class':'form-control',
                'type':'text',
                'placeholder':'Enter First Name'
            }),
            'Last_Name':forms.TextInput(attrs={
                'class':'form-control',
                'type':'text',
                'placeholder':'Enter Last Name'
            }),
            'Message':forms.Textarea(attrs={
                'class':'form-control',
                'type':'textarea',
                'row':2,
                'col':10,
                'placeholder':'write message....'
            })
        }

