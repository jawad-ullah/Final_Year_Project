from os import truncate
from django.contrib.auth.base_user import BaseUserManager
from django.core.exceptions import ValidationError
from django.db import models
from django.contrib.auth.models import AbstractUser
from .backends import CustomUserManager
import datetime
from django.utils.translation import ugettext_lazy as _

from django.http import request
# Department Model
class Department(models.Model):
    Department_name=models.CharField(max_length=50)

    def __str__(self):
        return f"{self.Department_name}"

    def get_courses(self):
        return self.course.all()
        
class Semister(models.Model):
    Department=models.ManyToManyField(Department,null=True)
    Semister_name=models.CharField(max_length=50)

    def __str__(self):
        return f"{self.Semister_name}"

#Time table Model
class TimeTable(models.Model):
    TimeTable=models.FileField(upload_to='timetables')
    Department=models.OneToOneField(Department,on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.Department}"


class User(AbstractUser):
    username=None
    email=models.EmailField(max_length=200,unique=True)
    Role=[
        ('Admin','Admin'),
        ('Teacher','Teacher'),
        ("Student",'Student'),
    ]

    Father_Name=models.CharField(max_length=100,default="")
    Address= models.TextField(max_length=255,default='Village,P/o,Tehsil,District')
    contact_no= models.CharField(max_length=15,default="")    
    Role=models.CharField(max_length=10,choices=Role, default=False,blank=True)
    Department= models.ForeignKey(Department, related_name='department', on_delete=models.CASCADE,null=True,blank=True)
    Semister= models.ForeignKey(Semister, related_name='semister', on_delete=models.CASCADE,null=True,blank=True)
    Profile_Img = models.FileField(upload_to='Profile', max_length = 100,null=True)
    is_Approved=models.BooleanField(default=False)

    USERNAME_FIELD='email';
    REQUIRED_FIELDS=[]
    object=CustomUserManager()
    
    def __str__(self):
        return f"{self.email}"
    
    def save(self, *args, **kwargs):
        if self.Role=='Admin':
           self.is_superuser=True
           self.is_Approved=True
        super().save(*args, **kwargs) # Call the real save() method
    
#Course Model
class Course(models.Model):
    Subject_name=models.CharField(max_length=100,help_text='Eg:Programing Fundamental in Computer science')
    credits=models.PositiveIntegerField(help_text="Select Credit hour (1,2,3,4)")
    catagory=models.CharField(max_length=100,null=True)
    Department=models.ForeignKey(Department,on_delete=models.CASCADE,null=True,related_name='course')
    Semister=models.ForeignKey(Semister,on_delete=models.CASCADE)
    Teacher=models.ForeignKey(User,on_delete=models.CASCADE,null=True,blank=True)

    def __str__(self):
        return f"{self.Subject_name}"

    def get_assignments(self):
        return self.assignments.all()


# Course Outline    
class Course_Outline(models.Model):
    File=models.FileField(upload_to='Course_Outline')
    Department=models.OneToOneField(Department,on_delete=models.CASCADE)

    def __str__(self):
        return f"Department {self.Department} - Semister {self.Semister}"
    

#Results
class SessionModel(models.Model):
    Session= models.CharField(max_length = 150,help_text='e.g: Session spring 2021')
    Approve = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.Session}"

    class Meta:
        db_table = 'SessionModel'
        verbose_name = 'SessionModel'
        verbose_name_plural = 'SessionModels'

class Result(models.Model):
    Result_type=[
        ('Final','Final Term'),
        ('Mid','Mid Term'),
    
    ]
    Session =models.ForeignKey(SessionModel, related_name='result', on_delete=models.CASCADE)
    result_type=models.CharField(max_length=20,choices=Result_type)
    Department=models.ForeignKey(Department,related_name='dept_result',on_delete=models.CASCADE)
    Semister=models.ForeignKey(Semister,related_name='Sem_result',on_delete=models.CASCADE,null=True)
    Result=models.FileField(upload_to='Results',null=True)
    Status=models.CharField(max_length=20,blank=True,null=True)
    
    def __str__(self):
        return f"{self.Session} - {self.Department} - {self.Semister}"

    class Meta:
        db_table = 'Result'
        verbose_name = 'Result'
        verbose_name_plural = 'Results'

    
    
# Lecture Model

class Lecture(models.Model):
    lecture_no=models.PositiveIntegerField(default='1')
    Department=models.ForeignKey(Department, on_delete=models.CASCADE, null=True)
    Semister=models.ForeignKey(Semister, on_delete=models.CASCADE,null=True)
    Subject=models.ForeignKey(Course,on_delete=models.CASCADE,null=True)
    LectureFile=models.FileField(upload_to='Lectures',max_length=255,null=True)
    created=models.DateField(auto_now_add=True)

    def __str__(self):
        return f"Lecture {self.lecture_no} -Department {self.Department} - Subject{self.Subject}"

class Assignment(models.Model):
    Assignemt_no=models.IntegerField(default='0',null=True)
    Subject=models.ForeignKey(Course,on_delete=models.CASCADE,null=True)
    Questions = models.TextField(max_length = 1000,null=True)
    created = models.DateField(editable=False,null=True)
    updated = models.DateTimeField(editable=False, null=True)
    deadline = models.DateField(null=True)

    def __str__(self):
	    return self.Questions

    def save(self,*args, **kwargs):
        self.created = datetime.date.today()
        self.updated = datetime.datetime.today()
        super().save(*args, **kwargs)

class Assignment_Solution(models.Model):
    is_Submit=[
        ('submit','submit'),
    ]
    assignment = models.ForeignKey(Assignment,on_delete=models.CASCADE,max_length=255,null=True,blank=True)
    Student = models.CharField(max_length=100,null=True,blank=True)
    Subject=models.CharField(max_length=100,null=True,blank=True)
    assignment_no=models.IntegerField(null=True,blank=True)
    submission_date = models.DateField(null=True,blank=True)
    Answer=models.FileField(upload_to='SubmittedAssignment' ,max_length=200,null=True)
    Status=models.CharField(max_length=20,choices=is_Submit,null=True,default=False)

    def __str__(self):
    	return self.Subject

    def save(self,*args, **kwargs):
    	self.submission_date = datetime.date.today()
    	super().save(*args, **kwargs)


class Contact(models.Model):
    First_name=models.CharField(max_length=100)
    Last_Name=models.CharField(max_length=100)
    Message=models.CharField(max_length=300)