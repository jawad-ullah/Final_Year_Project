# from django.db.models.signals import post_save
# from django.dispatch import receiver
# from core.models import *

# @receiver(post_save,sender=User)
# def create_profile(sender,instance,created,**kwargs):
#     print(sender)
#     print(instance)
#     print(created)
#     if created:
#         if instance.Role =="Teacher":
#             Teacher.objects.create(teacher=instance)