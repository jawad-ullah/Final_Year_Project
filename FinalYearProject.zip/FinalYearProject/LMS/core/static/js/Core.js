
	$(document).on("scroll", function(){
		if
      ($(document).scrollTop() > 86){
		  $("#banner").addClass("shrink");
		}
		else
		{
			$("#banner").removeClass("shrink");
		}
	});

  /* SLick Slider*/
$('.slick-slider-demo').slick({
  dots:true,
  infinite:true,
  autoplay:true,
  slidesToShow:1,
  slidesToScroll:1,
  speed:1000,
  prevArrow:'<span class="prev-arrow"><i class="fas fa-angle-left"></i></span>',
  nextArrow:'<span class="next-arrow"><i class="fas fa-angle-right"></i></span>',
  responsive:
  [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        conterMode:true,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 680,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        centerMode:true,
        infinite:true,
        dots:true,
        arrows:false,
      }
    },
    {
      breakpoint: 500,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        centerMode:false,
        dots:false,
      }
    }
  ]
});

$('.img').colorbox({
  'rel':'.img',
  transition:'fadeIn',
  scalePhotos:true,
  maxHeight:'400px',
  maxWidth:'100%',
  innerWidth:'40%',
  innerHeight:'100%',
  slideshow:false,
  Reposition:true,
})
  console.log("CORE IS READY")
    
  // Search faculty 

  const faculty=document.getElementById('faculty-search')
  const putTeacher=document.getElementById('PutTeachers')
  console.log(faculty)

  faculty.addEventListener('change',e=>{
    dept=e.target.value
    putTeacher.textContent=""
    console.log(dept);
    $.ajax({
      type:'GET',
      url:`/get-tea/${dept}/`,
      success:(response)=>{
        console.log(response.data);
        Data=response.data
        Data.forEach(t => {
          putTeacher.innerHTML+=
          `
            <tr>
                <td>${t.first_name} ${t.last_name}</td>
                <td>${t.email}</td>
                <td>${t.Role}</td>
                <td>${t.contact_no}</td>
                <td>${t.Address}</td>
                <td><img src="${t.Profile_Img}" width="60" height="50" class="rounded-circle" /></td>
                <td>
                <a href="/Detail/${t.id}/" class="btn btn-warning px-5">Detail</a>
                </td>
            </tr>
          `
        });
        
      },
      error:(error)=>{
        console.log(error);
      }
    })
  })