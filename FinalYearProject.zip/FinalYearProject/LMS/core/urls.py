from django.urls import path
from . import views

urlpatterns = [
    path('', views.home,name='home'),
    path('About/', views.About,name='about'),
    path('Contact/',views.Contact,name='contact'),
    path('principel message/',views.Principle_msg,name='Principle_msg'),
    path('Co Ordinator message/',views.Co_Ordinator_msg,name='Co_Ordinator_msg'),
    path('Programes/',views.Programes,name='Programes'),
    path('faculty/',views.faculty,name='faculty'),
    path('Detail/<int:id>/',views.Detail,name='detail'),

    #Ajax Jason

    path('get-tea/<int:id>/',views.get_teachers,name='get-tea'),
]

