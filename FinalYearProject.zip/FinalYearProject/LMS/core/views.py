from django.http.response import JsonResponse
from django.shortcuts import render,redirect
from .models import *
from django.contrib import messages
from .forms import ContactModelForm
# Create your views here.
def home(request):
    if request.user.is_authenticated:
        if request.user.Role=="Admin":
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=="Student":
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')
    
    depts=Department.objects.all().count()
    teachs=User.objects.filter(Role='Teacher').count()
    Studs=User.objects.filter(Role='Student').count()
    Cours=Course.objects.all().count()
    Context={
       'departments':str(depts),
       'Teachers':str(teachs),
       'Students':str(Studs),
       'Courses':str(Cours)
        }
    return render(request,'home.html',Context)

def Principle_msg(request):
    if not request.user.is_authenticated:
        return render(request,'Principle_msg.html')
    else:
        if request.user.Role=="Admin":
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')


def Co_Ordinator_msg(request):
    if not request.user.is_authenticated:
        return render(request,'Co-ordinator_msg.html')
    else:
        if request.user.Role=='Admin':
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')


def About(request):
    if not request.user.is_authenticated:
        return render(request,'About.html')
    else:
        if request.user.Role=='Admin':
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')

def Contact(request):
    if not request.user.is_authenticated:
        fm=ContactModelForm(request.POST or None)
        if request.method=='POST':
            if fm.is_valid():
                fm.save()
                messages.success(request,f"{request.user.username} Your message is Successfully recived")
                return redirect('/Contact/')
        context={
            'form':fm
        }
        return render(request,'contact.html',context)
    else:
        if request.user.Role=='Admin':
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')

def Programes(request):
    if not request.user.is_authenticated:
        dept=Department.objects.all()
        context={
            'dept':dept,
        }
        return render(request,'Programes.html',context)
    else:
        if request.user.Role=="Admin":
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')


def faculty(request):
    if not request.user.is_authenticated:
        tea=[]
        teachers=Department.objects.all()
        for t in teachers:
            tea.append(t)
        context={

            'tea':tea
        }
        return render(request,'Faculty.html',context)
    else:
        if request.user.Role=="Admin":
            return redirect('/Admin/Admin Dashboard/')
        elif request.user.Role=='Student':
            return redirect("/Student/Student_Dashboard/")
        else:
            return redirect('/Teacher/Teacher_Dashboard')

def Detail(request,id):
    if not request.user.is_authenticated:
        Id=id
        Tea=User.object.get(pk=Id)
        context={
            'tea':Tea
        }
    return render(request,'Detail.html',context)


def get_teachers(request,*args, **kwargs):
    Id=kwargs.get('id')
    teachers=[]
    get_users=User.objects.all().filter(Department_id=Id,Role="Teacher")
    for t in get_users:
        items={
            'id':t.id,
            'first_name':t.first_name,
            'last_name':t.last_name,
            'Father_Name':t.Father_Name,
            'email':t.email,
            'Address':t.Address,
            'contact_no':t.contact_no,
            'Department':t.Department.Department_name,
            'Profile_Img':t.Profile_Img.url,
            'is_Approved':t.is_Approved,
            'is_staff':t.is_staff,
            'is_active':t.is_active,
            'is_superuser':t.is_superuser,
            'last_login':t.last_login,
            'date_joined':t.date_joined,
            'Role':t.Role,
        }
        teachers.append(items)
    return JsonResponse({
        'data':teachers
    })